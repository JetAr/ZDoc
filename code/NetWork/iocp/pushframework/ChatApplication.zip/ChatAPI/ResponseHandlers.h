#pragma once

#include "ChatAPI.h"

class DirectChatResponseHandler : public ResponseHandler
{
public:
	DirectChatResponseHandler(ChatAPI* pSession)
	{
		this->pSession = pSession;
	}
	~DirectChatResponseHandler(){}
	virtual void handleResponse(PushFramework::IncomingPacket& packet)
	{
		DirectChatResponse& response = (DirectChatResponse&) packet;

		pSession->OnDirectChat(response.Sender(), response.Msg());
	}
private:
	ChatAPI* pSession;
};


//


class JoinRoomResponseHandler : public ResponseHandler
{
public:
	JoinRoomResponseHandler(ChatAPI* pSession)
	{
		this->pSession = pSession;
	}
	~JoinRoomResponseHandler(){}
	virtual void handleResponse(PushFramework::IncomingPacket& packet)
	{
		JoinRoomResponse& response = (JoinRoomResponse&) packet;

		pSession->OnJoinRoom(response.Room());
	}
private:
	ChatAPI* pSession;
};

//


class ParticipantInResponseHandler : public ResponseHandler
{
public:
	ParticipantInResponseHandler(ChatAPI* pSession)
	{
		this->pSession = pSession;
	}
	~ParticipantInResponseHandler(){}
	virtual void handleResponse(PushFramework::IncomingPacket& packet)
	{
		ParticipantInResponse& response = (ParticipantInResponse&) packet;

		pSession->OnParticipantIn(response.Pseudo());
	}
private:
	ChatAPI* pSession;
};


class ParticipantOutResponseHandler : public ResponseHandler
{
public:
	ParticipantOutResponseHandler(ChatAPI* pSession)
	{
		this->pSession = pSession;
	}
	~ParticipantOutResponseHandler(){}
	virtual void handleResponse(PushFramework::IncomingPacket& packet)
	{
		ParticipantOutResponse& response = (ParticipantOutResponse&) packet;

		pSession->OnParticipantOut(response.Pseudo());
	}
private:
	ChatAPI* pSession;
};

//

class RoomChatResponseHandler : public ResponseHandler
{
public:
	RoomChatResponseHandler(ChatAPI* pSession)
	{
		this->pSession = pSession;
	}
	~RoomChatResponseHandler(){}
	virtual void handleResponse(PushFramework::IncomingPacket& packet)
	{
		RoomChatResponse& response = (RoomChatResponse&) packet;

		pSession->OnRoomChat(response.Sender(), response.Msg(), response.Room());
	}
private:
	ChatAPI* pSession;
};

//

class LoginPuzzleResponseHandler : public ResponseHandler
{
public:
	LoginPuzzleResponseHandler(ChatAPI* pSession)
	{
		this->pSession = pSession;
	}
	~LoginPuzzleResponseHandler(){}
	virtual void handleResponse(PushFramework::IncomingPacket& packet)
	{
		LoginPuzzleResponse& response = (LoginPuzzleResponse&) packet;

		pSession->OnLoginPuzzle(response.PuzzleQuestion());
	}
private:
	ChatAPI* pSession;
};


//

class LoginResponseHandler : public ResponseHandler
{
public:
	LoginResponseHandler(ChatAPI* pSession)
	{
		this->pSession = pSession;
	}
	~LoginResponseHandler(){}
	virtual void handleResponse(PushFramework::IncomingPacket& packet)
	{
		LoginResponse& response = (LoginResponse&) packet;

		pSession->OnLoginResponse(response.BAccepted(), response.Msg());
	}
private:
	ChatAPI* pSession;
};

//

class RoomsResponseHandler : public ResponseHandler
{
public:
	RoomsResponseHandler(ChatAPI* pSession)
	{
		this->pSession = pSession;
	}
	~RoomsResponseHandler(){}
	virtual void handleResponse(PushFramework::IncomingPacket& packet)
	{
		RoomsResponse& response = (RoomsResponse&) packet;

		pSession->OnRooms(response.getRooms());
	}
private:
	ChatAPI* pSession;
};