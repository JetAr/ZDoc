#include "StdAfx.h"
#include "ChatClientProtocol.h"


#include "DirectChatResponse.h"
#include "JoinRoomResponse.h"
#include "LoginResponse.h"
#include "ParticipantInResponse.h"
#include "ParticipantOutResponse.h"
#include "RoomChatResponse.h"
#include "RoomsResponse.h"
#include "LoginPuzzleResponse.h"

ChatClientProtocol::ChatClientProtocol(void)
{
	registerPacketTemplate(DirectChatResponseID, new DirectChatResponse);
	registerPacketTemplate(JoinRoomResponseID, new JoinRoomResponse);
	registerPacketTemplate(LoginResponseID, new LoginResponse);
	registerPacketTemplate(ParticipantInResponseID, new ParticipantInResponse);
	registerPacketTemplate(ParticipantOutResponseID, new ParticipantOutResponse);
	registerPacketTemplate(RoomChatResponseID, new RoomChatResponse);
	registerPacketTemplate(RoomsResponseID, new RoomsResponse);
	registerPacketTemplate(LoginPuzzleResponseID, new LoginPuzzleResponse);
}

ChatClientProtocol::~ChatClientProtocol(void)
{
}
