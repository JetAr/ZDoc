#pragma once
#include "ChatPackets.h"

class CHATPACKETS_API ChatClientProtocol : public XMLProtocol
{
public:
	ChatClientProtocol(void);
	~ChatClientProtocol(void);
};
