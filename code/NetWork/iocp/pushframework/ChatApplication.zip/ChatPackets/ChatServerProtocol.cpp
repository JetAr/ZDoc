#include "StdAfx.h"
#include "ChatServerProtocol.h"

#include "LoginRequest.h"
#include "DirectChatRequest.h"
#include "JoinRoomRequest.h"
#include "LeaveRoomRequest.h"
#include "RoomChatRequest.h"
#include "LogoutRequest.h"

ChatServerProtocol::ChatServerProtocol(void)
{
	registerPacketTemplate(LoginRequestID, new LoginRequest);
	registerPacketTemplate(DirectChatRequestID, new DirectChatRequest);
	registerPacketTemplate(JoinRoomRequestID, new JoinRoomRequest);
	registerPacketTemplate(LeaveRoomRequestID, new LeaveRoomRequest);
	registerPacketTemplate(RoomChatRequestID, new RoomChatRequest);
	registerPacketTemplate(LogoutRequestID, new LogoutRequest);
}

ChatServerProtocol::~ChatServerProtocol(void)
{
}
