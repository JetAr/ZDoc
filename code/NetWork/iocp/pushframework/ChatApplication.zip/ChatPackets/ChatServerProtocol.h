#pragma once
#include "ChatPackets.h"

class CHATPACKETS_API ChatServerProtocol : public XMLProtocol
{
public:
	ChatServerProtocol(void);
	~ChatServerProtocol(void);
};
