#include "StdAfx.h"
#include "DirectChatRequest.h"

DirectChatRequest::DirectChatRequest(void)
:XMLRequest(DirectChatRequestID)
{
}

DirectChatRequest::~DirectChatRequest(void)
{
}

bool DirectChatRequest::FragmentXML()
{
	recipient = getArgumentAsText(L"to");
	msg = getArgumentAsText(L"msg");

	return true;
}

bool DirectChatRequest::ConstructXML()
{
	setArgumentAsText(L"to", recipient.c_str());
	setArgumentAsText(L"msg", msg.c_str());
	return true;
}

IncomingXMLPacket* DirectChatRequest::CreateInstance()
{
	return new DirectChatRequest;
}