#ifndef DirectChatRequest__INCLUDED
#define DirectChatRequest__INCLUDED

#pragma once

#include "ChatPackets.h"

class CHATPACKETS_API DirectChatRequest : public XMLRequest
{
public:
	DirectChatRequest(void);
	~DirectChatRequest(void);

	std::wstring Msg() const { return msg; }
	void Msg(std::wstring val) { msg = val; }
	std::wstring Recipient() const { return recipient; }
	void Recipient(std::wstring val) { recipient = val; }


private:
	std::wstring recipient;
	std::wstring msg;
	
protected:
	virtual bool FragmentXML();
	virtual bool ConstructXML();

	virtual IncomingXMLPacket* CreateInstance();


};
#endif // DirectChatRequest__INCLUDED
