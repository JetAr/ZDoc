#include "StdAfx.h"
#include "DirectChatResponse.h"

DirectChatResponse::DirectChatResponse(void)
:XMLResponse(DirectChatResponseID)
{
}

DirectChatResponse::~DirectChatResponse(void)
{
}

bool DirectChatResponse::FragmentXML()
{
	sender = getArgumentAsText(L"from");
	msg = getArgumentAsText(L"msg");

	return true;
}

bool DirectChatResponse::ConstructXML()
{
	setArgumentAsText(L"from", sender.c_str());
	setArgumentAsText(L"msg", msg.c_str());

	return true;
}

IncomingXMLPacket* DirectChatResponse::CreateInstance()
{
	return new DirectChatResponse;
}