#pragma once

#include "ChatPackets.h"

class CHATPACKETS_API DirectChatResponse : public XMLResponse
{
public:
	DirectChatResponse(void);
	~DirectChatResponse(void);

	std::wstring Msg() const { return msg; }
	void Msg(std::wstring val) { msg = val; }

	std::wstring Sender() const { return sender; }
	void Sender(std::wstring val) { sender = val; }

private:
	std::wstring sender;
	std::wstring msg;
	
protected:
	virtual bool FragmentXML();
	virtual bool ConstructXML();

	virtual IncomingXMLPacket* CreateInstance();
};
