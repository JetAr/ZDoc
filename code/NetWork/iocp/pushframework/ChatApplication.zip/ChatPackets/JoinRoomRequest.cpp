#include "StdAfx.h"
#include "JoinRoomRequest.h"

JoinRoomRequest::JoinRoomRequest(void)
:XMLRequest(JoinRoomRequestID)
{
}

JoinRoomRequest::~JoinRoomRequest(void)
{
}

bool JoinRoomRequest::FragmentXML()
{
	room = getArgumentAsText(L"room");
	return true;
}

bool JoinRoomRequest::ConstructXML()
{
	setArgumentAsText(L"room", room.c_str());
	return true;
}

IncomingXMLPacket* JoinRoomRequest::CreateInstance()
{
	return new JoinRoomRequest;
}