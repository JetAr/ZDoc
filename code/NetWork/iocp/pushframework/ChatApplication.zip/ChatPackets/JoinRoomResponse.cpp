#include "StdAfx.h"
#include "JoinRoomResponse.h"

JoinRoomResponse::JoinRoomResponse(void)
:XMLResponse(JoinRoomResponseID)
{
}

JoinRoomResponse::~JoinRoomResponse(void)
{
}

bool JoinRoomResponse::FragmentXML()
{
	room = getArgumentAsText(L"room");
	return true;
}

bool JoinRoomResponse::ConstructXML()
{
	setArgumentAsText(L"room", room.c_str());
	return true;
}

IncomingXMLPacket* JoinRoomResponse::CreateInstance()
{
	return new JoinRoomResponse;
}