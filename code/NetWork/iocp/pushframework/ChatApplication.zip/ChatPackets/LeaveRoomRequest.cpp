#include "StdAfx.h"
#include "LeaveRoomRequest.h"

LeaveRoomRequest::LeaveRoomRequest(void)
:XMLRequest(LeaveRoomRequestID)
{
}

LeaveRoomRequest::~LeaveRoomRequest(void)
{
}

bool LeaveRoomRequest::FragmentXML()
{
	room = getArgumentAsText(L"room");
	return true;
}

bool LeaveRoomRequest::ConstructXML()
{
	setArgumentAsText(L"room", room.c_str());
	return true;
}

IncomingXMLPacket* LeaveRoomRequest::CreateInstance()
{
	return new LeaveRoomRequest;
}