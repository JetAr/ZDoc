#ifndef LeaveRoomRequest__INCLUDED
#define LeaveRoomRequest__INCLUDED

#pragma once

#include "ChatPackets.h"

class CHATPACKETS_API LeaveRoomRequest : public XMLRequest
{
public:
	LeaveRoomRequest(void);
	~LeaveRoomRequest(void);
	
	std::wstring Room() const { return room; }
	void Room(std::wstring val) { room = val; }

private:
	std::wstring room;

protected:
	virtual bool FragmentXML();
	virtual bool ConstructXML();

	virtual IncomingXMLPacket* CreateInstance();
};
#endif // LeaveRoomRequest__INCLUDED
