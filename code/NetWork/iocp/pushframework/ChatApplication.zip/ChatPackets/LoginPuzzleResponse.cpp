#include "StdAfx.h"
#include "LoginPuzzleResponse.h"

LoginPuzzleResponse::LoginPuzzleResponse(void)
:XMLResponse(LoginPuzzleResponseID)
{
}

LoginPuzzleResponse::~LoginPuzzleResponse(void)
{
}

bool LoginPuzzleResponse::FragmentXML()
{
	puzzleQuestion = getArgumentAsInt(L"puzzle");
	return true;
}

bool LoginPuzzleResponse::ConstructXML()
{
	setArgumentAsInt(L"puzzle", puzzleQuestion);
	return true;
}

IncomingXMLPacket* LoginPuzzleResponse::CreateInstance()
{
	return new LoginPuzzleResponse();
}
