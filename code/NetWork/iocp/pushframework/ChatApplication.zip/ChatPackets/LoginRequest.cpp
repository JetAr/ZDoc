#include "StdAfx.h"
#include "LoginRequest.h"

LoginRequest::LoginRequest(void)
:XMLRequest(LoginRequestID)
{
}

LoginRequest::~LoginRequest(void)
{
}

bool LoginRequest::FragmentXML()
{
	pseudo = getArgumentAsText(L"pseudo");
	loginPuzzleReply = getArgumentAsInt(L"puzzleReply");
	return true;
}

bool LoginRequest::ConstructXML()
{
	setArgumentAsText(L"pseudo", pseudo.c_str());
	setArgumentAsInt(L"puzzleReply", loginPuzzleReply);
	return true;
}

IncomingXMLPacket* LoginRequest::CreateInstance()
{
	return new LoginRequest;
}