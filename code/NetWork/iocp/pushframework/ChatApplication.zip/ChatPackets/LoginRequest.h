#pragma once

#include "ChatPackets.h"

class CHATPACKETS_API LoginRequest : public XMLRequest
{
public:
	LoginRequest(void);
	~LoginRequest(void);
	
	std::wstring Pseudo() const { return pseudo; }
	void Pseudo(std::wstring val) { pseudo = val; }

	int LoginPuzzleReply() const { return loginPuzzleReply; }
	void LoginPuzzleReply(int val) { loginPuzzleReply = val; }
private:
	std::wstring pseudo;
	int loginPuzzleReply;

protected:
	virtual bool FragmentXML();
	virtual bool ConstructXML();

	virtual IncomingXMLPacket* CreateInstance();

};
