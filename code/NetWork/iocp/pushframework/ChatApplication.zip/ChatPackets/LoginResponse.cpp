#include "StdAfx.h"
#include "LoginResponse.h"

LoginResponse::LoginResponse(void)
:XMLResponse(LoginResponseID)
{
}

LoginResponse::~LoginResponse(void)
{
}

bool LoginResponse::FragmentXML()
{
	msg = getArgumentAsText(L"msg");
	bAccepted = getArgumentAsBool(L"accepted");
	return true;
}

bool LoginResponse::ConstructXML()
{
	setArgumentAsText(L"msg", msg.c_str());
	setArgumentAsBool(L"accepted", bAccepted);
	return true;
}

IncomingXMLPacket* LoginResponse::CreateInstance()
{
	return new LoginResponse;
}