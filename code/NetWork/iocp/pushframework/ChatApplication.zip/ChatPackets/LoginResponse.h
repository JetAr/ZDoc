#pragma once

#include "ChatPackets.h"

class CHATPACKETS_API LoginResponse : public XMLResponse
{
public:
	LoginResponse(void);
	~LoginResponse(void);
	std::wstring Msg() const { return msg; }
	void Msg(std::wstring val) { msg = val; }

	bool BAccepted() const { return bAccepted; }
	void BAccepted(bool val) { bAccepted = val; }
private:
	bool bAccepted;
	
	std::wstring msg;
	
protected:
	virtual bool FragmentXML();
	virtual bool ConstructXML();

	virtual IncomingXMLPacket* CreateInstance();


};
