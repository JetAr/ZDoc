#pragma once

#include "ChatPackets.h"

class CHATPACKETS_API LogoutRequest : public XMLRequest
{
public:
	LogoutRequest(void);
	~LogoutRequest(void);

protected:
	virtual bool FragmentXML();
	virtual bool ConstructXML();

	virtual IncomingXMLPacket* CreateInstance();


};
