#include "StdAfx.h"
#include "ParticipantInResponse.h"

ParticipantInResponse::ParticipantInResponse(void)
:XMLResponse(ParticipantInResponseID)
{
}

ParticipantInResponse::~ParticipantInResponse(void)
{
}

bool ParticipantInResponse::FragmentXML()
{
	pseudo = getArgumentAsText(L"pseudo");
	return true;
}

bool ParticipantInResponse::ConstructXML()
{
	setArgumentAsText(L"pseudo", pseudo.c_str());
	return true;
}

IncomingXMLPacket* ParticipantInResponse::CreateInstance()
{
	return new ParticipantInResponse;
}