#include "StdAfx.h"
#include "ParticipantOutResponse.h"

ParticipantOutResponse::ParticipantOutResponse(void)
:XMLResponse(ParticipantOutResponseID)
{
}

ParticipantOutResponse::~ParticipantOutResponse(void)
{
}

bool ParticipantOutResponse::FragmentXML()
{
	pseudo = getArgumentAsText(L"pseudo");
	return true;
}

bool ParticipantOutResponse::ConstructXML()
{
	setArgumentAsText(L"pseudo", pseudo.c_str());
	return true;
}

IncomingXMLPacket* ParticipantOutResponse::CreateInstance()
{
	return new ParticipantOutResponse;
}