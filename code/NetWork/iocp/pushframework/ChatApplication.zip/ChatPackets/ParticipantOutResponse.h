#pragma once

#include "ChatPackets.h"

class CHATPACKETS_API ParticipantOutResponse : public XMLResponse
{
public:
	ParticipantOutResponse(void);
	~ParticipantOutResponse(void);
	std::wstring Pseudo() const { return pseudo; }
	void Pseudo(std::wstring val) { pseudo = val; }
private:
	std::wstring pseudo;

protected:
	virtual bool FragmentXML();
	virtual bool ConstructXML();

	virtual IncomingXMLPacket* CreateInstance();
};
