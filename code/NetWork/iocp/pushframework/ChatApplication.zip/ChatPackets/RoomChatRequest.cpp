#include "StdAfx.h"
#include "RoomChatRequest.h"

RoomChatRequest::RoomChatRequest(void)
: XMLRequest(RoomChatRequestID)
{
}

RoomChatRequest::~RoomChatRequest(void)
{
}

bool RoomChatRequest::FragmentXML()
{
	msg = getArgumentAsText(L"msg");
	room = getArgumentAsText(L"room");

	return true;
}

bool RoomChatRequest::ConstructXML()
{
	setArgumentAsText(L"msg", msg.c_str());
	setArgumentAsText(L"room", room.c_str());

	return true;
}

IncomingXMLPacket* RoomChatRequest::CreateInstance()
{
	return new RoomChatRequest;
}