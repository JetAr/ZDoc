#pragma once

#include "ChatPackets.h"

class CHATPACKETS_API RoomChatRequest : public XMLRequest
{
public:
	RoomChatRequest(void);
	~RoomChatRequest(void);
	std::wstring Room() const { return room; }
	void Room(std::wstring val) { room = val; }
	std::wstring Msg() const { return msg; }
	void Msg(std::wstring val) { msg = val; }
private:
	std::wstring msg;
	std::wstring room;
protected:
	virtual bool FragmentXML();
	virtual bool ConstructXML();
	virtual IncomingXMLPacket* CreateInstance();
};
