#include "StdAfx.h"
#include "RoomChatResponse.h"

RoomChatResponse::RoomChatResponse(void)
:XMLResponse(RoomChatResponseID)
{
}

RoomChatResponse::~RoomChatResponse(void)
{
}

bool RoomChatResponse::FragmentXML()
{
	sender = getArgumentAsText(L"from");
	msg = getArgumentAsText(L"msg");
	room = getArgumentAsText(L"room");

	return true;
}

bool RoomChatResponse::ConstructXML()
{
	setArgumentAsText(L"from", sender.c_str());
	setArgumentAsText(L"msg", msg.c_str());
	setArgumentAsText(L"room", room.c_str());

	return true;
}

IncomingXMLPacket* RoomChatResponse::CreateInstance()
{
	return new RoomChatResponse;
}