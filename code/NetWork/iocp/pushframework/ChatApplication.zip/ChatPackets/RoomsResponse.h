#pragma once

#include "ChatPackets.h"

class CHATPACKETS_API RoomsResponse : public XMLResponse
{
public:
	RoomsResponse(void);
	~RoomsResponse(void);
	typedef std::vector<std::wstring> roomVectorT;
	roomVectorT& getRooms();
	void addRoom(std::wstring roomName);
private:
	roomVectorT roomVector;
protected:
	virtual bool FragmentXML();
	virtual bool ConstructXML();

	virtual IncomingXMLPacket* CreateInstance()
	{
		return new RoomsResponse();
	}
};
