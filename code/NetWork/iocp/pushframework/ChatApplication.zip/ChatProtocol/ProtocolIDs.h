#pragma once


typedef enum
{
	LoginRequestID = 1,
	DirectChatRequestID,
	JoinRoomRequestID,
	LeaveRoomRequestID,
	RoomChatRequestID,
	LogoutRequestID,


};

typedef enum
{
	LoginResponseID = 1,
	ParticipantInResponseID,
	ParticipantOutResponseID,
	RoomsResponseID,
	JoinRoomResponseID,
	DirectChatResponseID,
	RoomChatResponseID,
	LoginPuzzleResponseID,
};