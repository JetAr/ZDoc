#pragma once

class ChatParticipant : public PushFramework::Client
{
public:
	ChatParticipant(std::string pseudo);
	~ChatParticipant(void);
	virtual ClientKey getKey();
private:
	std::string pseudo;
};
