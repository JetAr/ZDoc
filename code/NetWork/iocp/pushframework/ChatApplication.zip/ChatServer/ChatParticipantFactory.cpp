#include "StdAfx.h"
#include "ChatParticipantFactory.h"

#include "ChatParticipant.h"

ChatParticipantFactory::ChatParticipantFactory(void)
{
}

ChatParticipantFactory::~ChatParticipantFactory(void)
{
}

int ChatParticipantFactory::onFirstRequest( PushFramework::IncomingPacket& request, void* lpContext, PushFramework::Client*& lpClient, PushFramework::OutgoingPacket*& lpPacket )
{
	LoginRequest& packet = (LoginRequest&) request;
	
	std::string pseudo = packet.Pseudo();

	int* pQuestion = (int*) lpContext;
	if (packet.LoginPuzzleReply() != ( (*pQuestion) + 1 ) )
	{
		LoginResponse* pLoginResponse = new LoginResponse;
		pLoginResponse->BAccepted(false);
		pLoginResponse->Msg("login puzzle is false");

		lpPacket = pLoginResponse;

		return PushFramework::ClientFactory::RefuseRequest;
	}
	
	ChatParticipant* pClient = new ChatParticipant(pseudo);
	lpClient = pClient;

	return PushFramework::ClientFactory::CreateClient;
}

PushFramework::OutgoingPacket* ChatParticipantFactory::onNewConnection( void*& lpContext )
{
	cout << "new connection, sending challenge" << std::endl;
	//Send the login challenge :
	LoginPuzzleResponse* pPuzzle = new LoginPuzzleResponse;

	int *randomVal = new int;
	*randomVal = rand()%100;

	pPuzzle->PuzzleQuestion(*randomVal); 

	lpContext = (void*) randomVal;

	return pPuzzle;
}

void ChatParticipantFactory::disposeClient( PushFramework::Client* pClient )
{
	delete pClient;
}

void ChatParticipantFactory::onBeforeDisposeClient( PushFramework::Client* pClient )
{
	getServer()->getBroadcastManager()->removePacket(pClient->getKey(), 0, "participants");
	
	ParticipantOutResponse* pPacket = new ParticipantOutResponse;
	pPacket->Pseudo() = pClient->getKey();

	getServer()->getBroadcastManager()->pushPacket(pPacket, "signals", "", 0);
}

void ChatParticipantFactory::onClientConnected( ClientKey key )
{
	//When a client connects.
	ChatParticipant* pParticipant = (ChatParticipant*) getClient(key);
	if (pParticipant)
	{
		LoginResponse* pLoginResponse = new LoginResponse;
		pLoginResponse->BAccepted(true);
		pLoginResponse->Msg("welcome to server");
		pParticipant->pushPacket(pLoginResponse);


		ParticipantInResponse* pPacket = new ParticipantInResponse;
		pPacket->Pseudo(key);
		getServer()->getBroadcastManager()->pushPacket(pPacket, "participants", key, 0);


		returnClient(key);
	}
}

void ChatParticipantFactory::onClientDisconnected( ClientKey clientKey )
{
	ChatParticipant* pParticipant = (ChatParticipant*) getClient(clientKey);
	if(!pParticipant)
		return;

	pParticipant->disconnect(false);

	returnClient(clientKey);
}
