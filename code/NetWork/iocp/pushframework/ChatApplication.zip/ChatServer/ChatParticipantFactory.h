#pragma once

class ChatParticipantFactory : public PushFramework::ClientFactory
{
public:
	ChatParticipantFactory(void);
	~ChatParticipantFactory(void);
protected:
	virtual PushFramework::OutgoingPacket* onNewConnection(void*& lpContext);
	virtual void onClientDisconnected(ClientKey key);
	virtual void onBeforeDisposeClient(PushFramework::Client* pClient);
	virtual void onClientReconnected(ClientKey key)
	{
		//
	}
	virtual void onClientConnected(ClientKey key);
	virtual void disposeClient(PushFramework::Client* pClient);
	virtual int onFirstRequest(PushFramework::IncomingPacket& request, void* lpContext, PushFramework::Client*& lpClient, PushFramework::OutgoingPacket*& lpPacket);




};
