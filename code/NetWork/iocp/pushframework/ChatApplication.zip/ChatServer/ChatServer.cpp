// ChatServer.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


#include "DirectChatRequestService.h"
#include "JoinRoomRequestService.h"
#include "LeaveRoomRequestService.h"
#include "RoomChatRequestService.h"
#include "LogoutRequestService.h"

#include "ChatParticipantFactory.h"

class ChatServer : public PushFramework::Server
{
	virtual void disposeOutgoingPacket(PushFramework::OutgoingPacket* pPacket)
	{
		delete pPacket;
	}
};



typedef struct Options_t
{
	int port;
	int monitorPort;
	std::string monitorPwd;
	int sampleRate;
	bool disableRooms;
}Options_t;
void readConfig(std::string& strIniFile, Options_t& options);
bool getConfigFile( std::string& path );
Options_t globalOptions;




int _tmain(int argc, _TCHAR* argv[])
{
	std::string strIniFile;
	if (!getConfigFile(strIniFile)){
		cout << "Unable to find conf file" << endl;
		return -1;
	}
	readConfig(strIniFile, globalOptions);


	ChatServer server;

	server.setServerInfos("Chat Server by Ahmed Charfeddine");



	server.registerService(DirectChatRequestID, new DirectChatRequestService, "directChat");
	server.registerService(JoinRoomRequestID, new JoinRoomRequestService, "joinRoom");
	server.registerService(LeaveRoomRequestID, new LeaveRoomRequestService, "leaveRoom");
	server.registerService(RoomChatRequestID, new RoomChatRequestService, "roomChat");
	server.registerService(LogoutRequestID, new LogoutRequestService, "logout");

	server.setClientFactory(new ChatParticipantFactory);
	server.setMaxConnections(10000);
	server.setLoginExpiryDuration(60);
	server.setProtocol(new ChatServerProtocol);

	PushFramework::ListenerOptions options;
	options.listeningBackLog = 10000;
	options.uSendBufferSize = 8196;
	options.uReadBufferSize = 8192;
	options.uIntermediateSendBufferSize = 8192*2;
	options.uIntermediateReceiveBufferSize = 8192*3;


	server.createListener(globalOptions.port, &options);
	server.enableRemoteMonitor(globalOptions.monitorPort, globalOptions.monitorPwd.c_str());
	server.enableProfiling(globalOptions.sampleRate);

	//Broadcast channels :

	if (!globalOptions.disableRooms)
	{
		server.getBroadcastManager()->createChannel("participants", 1000, false, 10, 20);
		server.getBroadcastManager()->createChannel("signals", 20, false,  7, 1);

		server.getBroadcastManager()->createChannel("room1", 20, true, 5, 3);
		server.getBroadcastManager()->createChannel("room2", 20, true, 5, 3);
		server.getBroadcastManager()->createChannel("room3", 20, true, 5, 3);
	}
	
	


	


	try
	{
		server.start(true);
	}
	catch (std::exception& e)
	{
		cout << "Failed to start server. Exception : " << e.what() << std::endl;
		return 0;
	}

	RoomsResponse* pRoomsPacket = new RoomsResponse;
	pRoomsPacket->addRoom("room1");
	pRoomsPacket->addRoom("room2");
	pRoomsPacket->addRoom("room3");
	server.getBroadcastManager()->pushPacket(pRoomsPacket, "signals", "", 0);
	

	int ch;
	
	do 
	{
		ch = _getch();
		ch = toupper(ch);
	} while (ch !='Q');

	server.stop();

	return 0;
}




void readConfig(std::string& strIniFile, Options_t& options)
{
	options.port = GetPrivateProfileIntA("server",  "port", 2011, strIniFile.c_str());
	options.monitorPort = GetPrivateProfileIntA("server",  "monitoringPort", 2012, strIniFile.c_str());

	char pwd[256];
	GetPrivateProfileStringA("server",  "monitoringPwd", "ahmed", pwd, 256, strIniFile.c_str());
	options.monitorPwd = pwd;

	options.sampleRate = GetPrivateProfileIntA("server",  "sampleRate", 10, strIniFile.c_str());
	options.disableRooms = (GetPrivateProfileIntA("chat",  "disableRooms", 0, strIniFile.c_str()) == 1);
}
bool getConfigFile( std::string& path )
{
	char szPath[MAX_PATH];
	if( !GetModuleFileNameA( NULL, szPath, MAX_PATH ) )
		return 1;
	std::string strPath(szPath);
	std::string::size_type pos1 = strPath.rfind('\\');
	std::string::size_type pos2 = strPath.rfind('/');
	std::string::size_type pos = (pos1==-1) ? pos2 : (pos2==-1) ? pos1 : (max(pos1, pos2));
	szPath[pos] = '\0';
	std::string strModuleDirectory(szPath);

	path = strModuleDirectory + "\\ChatServer.ini";

	return true;
}