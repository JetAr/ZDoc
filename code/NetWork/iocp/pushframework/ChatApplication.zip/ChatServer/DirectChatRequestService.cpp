#include "StdAfx.h"
#include "DirectChatRequestService.h"

#include "ChatParticipant.h"

#include "MyWatch.h"
#include <time.h>

DirectChatRequestService::DirectChatRequestService(void)
{
	ZeroMemory(&m_QPFrequency, sizeof(m_QPFrequency));
	QueryPerformanceFrequency(&m_QPFrequency);
}

DirectChatRequestService::~DirectChatRequestService(void)
{
}

void DirectChatRequestService::handle( ClientKey clientKey, PushFramework::IncomingPacket* pRequest )
{

	//wcout << L"\t\tDirect chat" << std::endl;
	/*
MyWatch watch(m_QPFrequency);
	DWORD dwStart = GetTickCount();	
*/


	ChatParticipant* pParticipant = (ChatParticipant*) getServer()->getClientFactory()->getClient(clientKey);
	if(!pParticipant)
		return;

	DirectChatRequest* request = (DirectChatRequest*) pRequest;

	ChatParticipant* pRecipient = (ChatParticipant*) getServer()->getClientFactory()->getClient(request->Recipient().c_str());
	if (pRecipient)
	{
		DirectChatResponse ChatResponse;// = new DirectChatResponse;
		ChatResponse.Sender(clientKey);
		ChatResponse.Msg(request->Msg());

		//watch.GetElapsedTime();
		pRecipient->pushPacket(&ChatResponse);
		//wcout << L"PushPacket : " << watch.GetElapsedTime() << std::endl;


		getServer()->getClientFactory()->returnClient(pRecipient->getKey());
	}

	getServer()->getClientFactory()->returnClient(clientKey);


/*
	DWORD dwCurrent = GetTickCount();
	DWORD dwDuration = dwCurrent - dwStart;



	wcout << L"Perfs : " << watch.GetElapsedTime() << std::endl;
	wcout << L"Ticks : " << dwDuration << std::endl;*/

}