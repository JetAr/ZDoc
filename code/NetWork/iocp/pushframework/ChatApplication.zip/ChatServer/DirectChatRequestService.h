#pragma once

class DirectChatRequestService : public PushFramework::Service
{
public:
	DirectChatRequestService(void);
	~DirectChatRequestService(void);
	
	virtual void handle(ClientKey clientKey, PushFramework::IncomingPacket* pRequest);

	LARGE_INTEGER	m_QPFrequency;
};
