#include "StdAfx.h"
#include "JoinRoomRequestService.h"

#include "ChatParticipant.h"

JoinRoomRequestService::JoinRoomRequestService(void)
{
}

JoinRoomRequestService::~JoinRoomRequestService(void)
{
}

void JoinRoomRequestService::handle( ClientKey clientKey, PushFramework::IncomingPacket* pRequest )
{
	ChatParticipant* pParticipant = (ChatParticipant*) getServer()->getClientFactory()->getClient(clientKey);
	if(!pParticipant)
		return;

	JoinRoomRequest* request = (JoinRoomRequest*) pRequest;

	std::string roomName = request->Room();

	getServer()->getBroadcastManager()->subscribeClient(clientKey, roomName.c_str());

	JoinRoomResponse* pResponse = new JoinRoomResponse;
	pResponse->Room(roomName);

	pParticipant->pushPacket(pResponse);

	getServer()->getClientFactory()->returnClient(clientKey);
}