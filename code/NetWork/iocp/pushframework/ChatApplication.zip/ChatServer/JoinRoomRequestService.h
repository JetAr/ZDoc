#pragma once

class JoinRoomRequestService : public PushFramework::Service
{
public:
	JoinRoomRequestService(void);
	~JoinRoomRequestService(void);

	void handle( ClientKey clientKey, PushFramework::IncomingPacket* pRequest );
};
