#include "StdAfx.h"
#include "LeaveRoomRequestService.h"

#include "ChatParticipant.h"

LeaveRoomRequestService::LeaveRoomRequestService(void)
{
}

LeaveRoomRequestService::~LeaveRoomRequestService(void)
{
}

void LeaveRoomRequestService::handle( ClientKey clientKey, PushFramework::IncomingPacket* pRequest )
{
	ChatParticipant* pParticipant = (ChatParticipant*) getServer()->getClientFactory()->getClient(clientKey);
	if(!pParticipant)
		return;

	LeaveRoomRequest* request = (LeaveRoomRequest*) pRequest;

	std::string roomName = request->Room();

	getServer()->getBroadcastManager()->unsubscribeClient(clientKey, roomName.c_str());

	getServer()->getClientFactory()->returnClient(clientKey);
}