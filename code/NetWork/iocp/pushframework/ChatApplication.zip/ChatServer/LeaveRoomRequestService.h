#pragma once

class LeaveRoomRequestService : public PushFramework::Service
{
public:
	LeaveRoomRequestService(void);
	~LeaveRoomRequestService(void);

	void handle( ClientKey clientKey, PushFramework::IncomingPacket* pRequest );
};
