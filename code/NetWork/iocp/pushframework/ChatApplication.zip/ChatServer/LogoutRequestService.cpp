#include "StdAfx.h"
#include "LogoutRequestService.h"

#include "ChatParticipant.h"

LogoutRequestService::LogoutRequestService(void)
{
}

LogoutRequestService::~LogoutRequestService(void)
{
}

void LogoutRequestService::handle( ClientKey clientKey, PushFramework::IncomingPacket* pRequest )
{
	ChatParticipant* pParticipant = (ChatParticipant*) getServer()->getClientFactory()->getClient(clientKey);
	if(!pParticipant)
		return;

	pParticipant->disconnect(false);

	getServer()->getClientFactory()->returnClient(clientKey);
}