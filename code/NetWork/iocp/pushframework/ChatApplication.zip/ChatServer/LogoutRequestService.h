#pragma once

class LogoutRequestService : public PushFramework::Service
{
public:
	LogoutRequestService(void);
	~LogoutRequestService(void);
	void handle( ClientKey clientKey, PushFramework::IncomingPacket* pRequest );
};
