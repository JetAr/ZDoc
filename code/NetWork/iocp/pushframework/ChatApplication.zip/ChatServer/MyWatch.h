#pragma once

class MyWatch
{
public:

	MyWatch(LARGE_INTEGER&	m_QPFrequency)
	{
		this->m_QPFrequency = m_QPFrequency;

		ZeroMemory(&m_StartCounter,sizeof(m_StartCounter));
		QueryPerformanceCounter (&m_StartCounter);

		reset();

	}

	void reset()
	{
		ZeroMemory(&m_LastCounter,sizeof(m_LastCounter));
		QueryPerformanceCounter (&m_LastCounter);
	}
	~MyWatch(void)
	{
	}

	double GetElapsedTime(bool bStart = true)
	{
		LARGE_INTEGER	curCounter;
		ZeroMemory(&curCounter, sizeof(curCounter));
		QueryPerformanceCounter (&curCounter);
		//
		__int64			m_ElapsedTime=(curCounter.QuadPart  - (bStart ? m_StartCounter.QuadPart :  m_LastCounter.QuadPart));

		if(!bStart)
			reset();

		return (static_cast<double>(m_ElapsedTime) / static_cast<double>(m_QPFrequency.QuadPart));
	}
private:
	LARGE_INTEGER	m_QPFrequency;
	LARGE_INTEGER	m_StartCounter;
	LARGE_INTEGER	m_LastCounter;
};