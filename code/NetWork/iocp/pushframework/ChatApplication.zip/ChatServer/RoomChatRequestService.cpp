#include "StdAfx.h"
#include "RoomChatRequestService.h"

#include "ChatParticipant.h"

RoomChatRequestService::RoomChatRequestService(void)
{
}

RoomChatRequestService::~RoomChatRequestService(void)
{
}

void RoomChatRequestService::handle( ClientKey clientKey, PushFramework::IncomingPacket* pRequest )
{
	wcout << L"\t\tRoom chat" << std::endl;

	ChatParticipant* pParticipant = (ChatParticipant*) getServer()->getClientFactory()->getClient(clientKey);
	if(!pParticipant)
		return;

	RoomChatRequest* request = (RoomChatRequest*) pRequest;

	RoomChatResponse* pResponse = new RoomChatResponse;

	pResponse->Sender(clientKey);
	pResponse->Msg(request->Msg());
	pResponse->Room(request->Room());

	getServer()->getBroadcastManager()->pushPacket(pResponse, request->Room().c_str(), "", 0);

	getServer()->getClientFactory()->returnClient(clientKey);
}