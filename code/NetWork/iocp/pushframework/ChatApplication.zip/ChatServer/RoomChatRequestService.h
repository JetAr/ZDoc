#pragma once

class RoomChatRequestService : public PushFramework::Service
{
public:
	RoomChatRequestService(void);
	~RoomChatRequestService(void);

	void handle( ClientKey clientKey, PushFramework::IncomingPacket* pRequest );
};
