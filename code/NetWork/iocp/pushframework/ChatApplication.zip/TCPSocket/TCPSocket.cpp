#include "stdafx.h"
#include "TCPSocket.h"


#include "TCPSocketEvents.h"
#include "TCPSocketImpl.h"
#include "ResponseHandler.h"


TCPSocket::TCPSocket(bool relayToUserThread)
{
	this->relayTCPEvents = relayToUserThread;
	pImpl = new TCPSocketImpl(this);
}

TCPSocket::~TCPSocket()
{
	delete pImpl;
}

bool TCPSocket::connect( const char* hostAddress, unsigned int uPort )
{
	return pImpl->connect(hostAddress, uPort);
}



void TCPSocket::registerHandler( unsigned int requestId, ResponseHandler* pHandler )
{
	pImpl->registerHandler(requestId, pHandler);
}

void TCPSocket::setProtocol( PushFramework::Protocol* pProtocol )
{
	pImpl->setProtocol(pProtocol);
}

bool TCPSocket::sendRequest( PushFramework::OutgoingPacket* pPacket )
{
	bool bRet = pImpl->sendRequest(pPacket);
	if(!bRet)
		cout << "failed to send request" << endl;
	return bRet;
}

int TCPSocket::getStatus()
{
	return pImpl->getStatus();
}

bool TCPSocket::initializeWinsock()
{
	WSADATA wsaData;
	WSAStartup(MAKEWORD(2,2), &wsaData);
	return true;
}

void TCPSocket::disconnect( bool waitForSend /*= true */ )
{
	pImpl->disconnect(waitForSend);
}

void TCPSocket::onPerformAutomatedJob()
{
	//
}

void TCPSocket::PostQueuedConnectionStatusEvent( ConnectionStatusEvent* pEvent )
{
	//Left for child
}

void TCPSocket::PostQueuedDataReceivedEvent( ReceivedDataEvent* pEvent )
{
	//left for child
}

void TCPSocket::ProcessQueuedConnectionStatusEvent( ConnectionStatusEvent* pEvent )
{
	if (pEvent->type == ConnectionStatusEvent::ConnectionProgress)
		onConnected(pEvent->bStatus);
	if(pEvent->type == ConnectionStatusEvent::ConnectionStatus)
		onConnectionClosed(pEvent->bStatus);
}

void TCPSocket::ProcessQueuedResponseEvent( ReceivedDataEvent* pEvent )
{
	pImpl->dispatchResponse(pEvent->commandId, *pEvent->pPacket);
}

bool TCPSocket::listen( int uListenPort, const char* interfaceAddress /*= NULL*/ )
{
	return pImpl->listen(uListenPort, interfaceAddress);
}

void TCPSocket::stopServer()
{
	pImpl->stopServer();
}
