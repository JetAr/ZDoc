#pragma once

#include "Symbols.h"


class TCPSocketImpl;
class ResponseHandler;

struct ConnectionStatusEvent;
struct ReceivedDataEvent;


namespace PushFramework
{
	class Protocol;
	class OutgoingPacket;
	class IncomingPacket;
}


class TCPSOCKET_API TCPSocket
{
	friend class TCPSocketImpl;
public:
	typedef enum
	{
		Disconnected = 1,
		Connecting,
		Connected,
		WaitingToClose
	};

	TCPSocket(bool relayToUserThread = false);
	~TCPSocket();

	static bool initializeWinsock();

	bool connect(const char* hostAddress, unsigned int uPort);
	void registerHandler(unsigned int requestId, ResponseHandler* pHandler);
	void setProtocol(PushFramework::Protocol* pProtocol);
	bool sendRequest(PushFramework::OutgoingPacket* pPacket);
	int getStatus();
	void disconnect(bool waitForSend = true );

	bool listen(int uListenPort, const char* interfaceAddress = NULL);
	void stopServer();
	virtual void OnReadyToSend()
	{
		//
	}


protected:
	virtual void onConnected(bool bResult) = 0;
	virtual void onConnectionClosed(bool bPeerClose) = 0;
	virtual void onPerformAutomatedJob();


	//For in user thread processing :
	virtual void PostQueuedConnectionStatusEvent(ConnectionStatusEvent* pEvent);
	virtual void PostQueuedDataReceivedEvent(ReceivedDataEvent* pEvent);

public:
	void ProcessQueuedConnectionStatusEvent(ConnectionStatusEvent* pEvent);
	void ProcessQueuedResponseEvent(ReceivedDataEvent* pEvent);
	bool isRelayTCPEvents() const { return relayTCPEvents; }

private:
	TCPSocketImpl* pImpl;
	bool relayTCPEvents;
};