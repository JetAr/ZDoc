#pragma once

#include "Symbols.h"


namespace PushFramework
{
	class IncomingPacket;
}



struct TCPSOCKET_API ConnectionStatusEvent
{
	typedef enum
	{
		ConnectionProgress = 0,
		ConnectionStatus
	};
	int type;
	bool bStatus;
};
struct TCPSOCKET_API ReceivedDataEvent
{
	int commandId;
	PushFramework::IncomingPacket* pPacket;
};