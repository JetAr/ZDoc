#pragma once


class TCPSocket;
class ResponseHandler;


class TCPSocketImpl
{
public:
	TCPSocketImpl(TCPSocket* pFacade);
	~TCPSocketImpl(void);

	int getStatus();

	bool connect(const char* hostAddress, unsigned int uPort);
	void registerHandler(unsigned int requestId, ResponseHandler* pHandler);
	void setProtocol(PushFramework::Protocol* pProtocol);
	PushFramework::Protocol* getPProtocol() const { return pProtocol; }
	bool sendRequest(PushFramework::OutgoingPacket* pPacket);
	void disconnect(bool waitForSend );
	void dispatchResponse( unsigned int requestId, PushFramework::IncomingPacket& packet );

	//Server Mode only
	bool listen(int uListenPort, const char* interfaceAddress = NULL);
	void stopServer();
	
private:
	TCPSocket* pFacade;

	int status;

	std::string strIP;
	unsigned int uPort;

	HANDLE hThread;
	UINT m_dwThreadId;
	
	HANDLE hKillEvent;

	WSAEVENT hSocketEvent;
	SOCKET hSocket;

	PushFramework::DataBuffer oBuffer;
	PushFramework::DataBuffer inBuffer;

	PushFramework::Protocol* pProtocol;


	typedef std::map<unsigned int, ResponseHandler*> handlerMapT;
	handlerMapT handlerMap;

	CRITICAL_SECTION cs;
private:
	static unsigned __stdcall threadProc(LPVOID lParam);

	void doClientLoop(bool bServerMode = false);


	bool OnRead();
	bool OnWrite();
	bool OnConnect();
	bool OnClose();

	bool bSendInProgress;

	bool WriteBytes();

	/////// SERVER MODE : 

	WSAEVENT hServerSocketEvent;
	SOCKET hServerSocket;
	
	bool SetupListeningSocket(const char* interfaceAddress, int uPort);
	void doServerLoop();


	static unsigned __stdcall threadProcServer(LPVOID lParam);

	void handleNewClient(SOCKET clientSocket);



};
