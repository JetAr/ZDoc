#include "StdAfx.h"
#include "OutgoingXMLPacket.h"

#include "Utilities.h"


OutgoingXMLPacket::OutgoingXMLPacket( unsigned int uCommandID )
{
	this->uCommandID = uCommandID;
	xRoot = XMLNode::createXMLTopNode("r");
	//
	bEncoded = false;
	pEncodedString = NULL;
	uBufferSize = 0;
}

OutgoingXMLPacket::~OutgoingXMLPacket()
{
	freeXMLString(pEncodedString);
}

void OutgoingXMLPacket::setArgumentAsText( char* argName, const char* sArgVal )
{
	xRoot.addChild(argName).addAttribute("v", sArgVal);
}

void OutgoingXMLPacket::setArgumentAsInt( char* argName, int iArgVal )
{
	char sArgVal [33];
	itoa (iArgVal,sArgVal,10);
	setArgumentAsText(argName, sArgVal);
}

void OutgoingXMLPacket::setArgumentAsBool( char* argName, bool bArgVal )
{
	setArgumentAsText(argName, bArgVal ? "1" : "0");
}

bool OutgoingXMLPacket::Encode()
{
	if(bEncoded)
		return true;
	if(!ConstructXML())
		return false;
	int nSize;
	pEncodedString = xRoot.createXMLString(0, &nSize);
	uBufferSize = nSize * sizeof(char);
	bEncoded = true;
	return true;
}

unsigned int OutgoingXMLPacket::getBufferLen()
{
	return uBufferSize;
}

char* OutgoingXMLPacket::getBuffer()
{
	return pEncodedString;
}

unsigned int OutgoingXMLPacket::getRequestId()
{
	return uCommandID;
}

XMLNode OutgoingXMLPacket::getOutputXML()
{
	return xRoot;
}