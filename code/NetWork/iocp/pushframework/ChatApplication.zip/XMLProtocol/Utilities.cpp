#include "StdAfx.h"
#include "Utilities.h"

Utilities::Utilities(void)
{
}

Utilities::~Utilities(void)
{
}

std::wstring Utilities::stringBuilder( const wchar_t *fmt, ... )
{
	va_list args;
	va_start(args, fmt);

	if (!fmt) return L"";
	int   result = -1, length = 1024;
	wchar_t *buffer = 0;
	while (result == -1)    {
		if (buffer)
			delete [] buffer;
		buffer = new wchar_t [length + 1];
		memset(buffer, 0, (length + 1)* sizeof(wchar_t));

		result = _vsnwprintf(buffer, length, fmt, args);
		length *= 2;
	}
	va_end(args);

	std::wstring s(buffer);
	delete [] buffer;
	return s;
}