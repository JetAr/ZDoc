#ifndef Utilities__INCLUDED
#define Utilities__INCLUDED

#pragma once

class Utilities
{
public:
	Utilities(void);
	~Utilities(void);
	static std::wstring stringBuilder( const wchar_t *fmt, ... );
};
#endif // Utilities__INCLUDED
