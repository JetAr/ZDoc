#include "StdAfx.h"
#include "XMLRequest.h"

XMLRequest::XMLRequest(unsigned int serviceId)
:OutgoingXMLPacket(serviceId)
{
}

XMLRequest::~XMLRequest(void)
{
}
