#include "StdAfx.h"
#include "XMLResponse.h"

XMLResponse::XMLResponse(unsigned int serviceId)
:OutgoingXMLPacket(serviceId)
{
}

XMLResponse::~XMLResponse(void)
{
}
