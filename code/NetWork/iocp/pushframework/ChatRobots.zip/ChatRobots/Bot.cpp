#include "StdAfx.h"
#include "Bot.h"



Bot::Bot(Options_t& _options)
:options(_options)
{
	isLogged = false;
	//
}

Bot::~Bot(void)
{
	//
}

unsigned int Bot::getLoggedTime()
{
	if(isLogged)
	{
		COleDateTimeSpan dtSpan = COleDateTime::GetCurrentTime() - dtLoggedTime;
		return dtSpan.GetTotalSeconds();
	}
	return 0;
}

void Bot::setLogged()
{
	dtLoggedTime = COleDateTime::GetCurrentTime();
	isLogged = true;
}

void Bot::onPerformAutomatedJob()
{
	if (!isLogged)
		return;

	static int nCentiSec = 0;
	static int nSecs = 0;
	
	
	if(nCentiSec == 10)
	{
		nSecs++;
		nCentiSec = 0;
	}
	else
		nCentiSec ++;


	if (options.sendRoomChatDuration > 0 && (nSecs % options.sendRoomChatDuration ==  0) )
	{
		SendChatToJoinedRoom();
	}


	for (int i=0;i<options.directChatBulks;i++)
		SendChatToRandomClient();

	/*
	if (options.directChatDuration > 0 && (nSecs % options.directChatDuration == 0) )
		{
			for (int i=0;i<options.directChatBulks;i++)
				SendChatToRandomClient();
		}*/
	

	if (options.joinRoomDuration > 0 && (nSecs % options.joinRoomDuration == 0) )
	{
		JoinRandomRoom();
	}

	if (getLoggedTime() > options.stayDuration)
	{
		Logout();
	}
	
}

void Bot::onConnected( bool bResult )
{
	if(bResult)
	{
		cout << ChatAPI::getPseudo() << " has succesfully connected" << std::endl;
	}
	else
	{
		cout << ChatAPI::getPseudo() << " has failed to connect" << std::endl;
	}
}

void Bot::OnLoginResponse( bool bAccepted, std::string msg )
{
	if(bAccepted)
	{
		setLogged();
		cout << ChatAPI::getPseudo() << " has logged in" << std::endl;
	}
	else
	{
		cout << ChatAPI::getPseudo() << " was unable to login" << std::endl;
	}
}

void Bot::OnRooms( std::vector<std::string>& roomsList )
{
	this->roomsList = roomsList;
}

void Bot::onConnectionClosed( bool bPeerClose )
{
	isLogged = false;
	cout << ChatAPI::getPseudo() << " 'connection was closed" << std::endl;
}

void Bot::OnDirectChat( std::string sender, std::string msg )
{

	if (options.replyDirectProb > 0)
	{
		if (rand() % 100  > directChatSinking)
		{
			std::string str = "hi " + sender + " i received ur msg";
			SendDirectChat(sender, str);
		}
	}
	
}

void Bot::OnJoinRoom( std::string roomName )
{
	joinedRoom = roomName;
}

