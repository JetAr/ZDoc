#pragma once




typedef struct Options_t
{
	std::string serverIP;
	int port;
	int stayDuration;
	int directChatDuration;
	int directChatBulks;
	int joinRoomDuration;
	int replyDirectProb;
	int sendRoomChatDuration;
	int nConnectAtOnce;
	int stagedPhaseDuration;
	int stagedConnectionPerSecond;
}Options_t;


class Bot : public ChatAPI
{
public:
	Bot(Options_t& options);
	~Bot(void);
private:
	Options_t& options;
	virtual void onConnected(bool bResult);
	virtual void onConnectionClosed(bool bPeerClose);
	virtual void OnDirectChat(std::string sender, std::string msg);
	virtual void OnJoinRoom(std::string roomName);
	virtual void OnParticipantIn(std::string pseudo)
	{
		clientVect.push_back(pseudo);
	}
	virtual void OnParticipantOut(std::string pseudo)
	{
		//
	}
	virtual void OnRoomChat(std::string sender, std::string msg, std::string room)
	{
		//
	}
	virtual void OnRooms(std::vector<std::string>& roomsList);
	virtual void OnLoginResponse(bool bAccepted, std::string msg);
	


	void onPerformAutomatedJob();

	void setLogged();
	unsigned int getLoggedTime();
	
private:
	std::string pseudo;
	bool isLogged;
	COleDateTime dtLoggedTime;
	//
	std::vector<std::string> clientVect;
	std::vector<std::string> roomsList;
	std::string joinedRoom;
private:
	int roomChatFreq;
	int directChatFreq;
	int directChatSinking;
	int joinRoomFreq;

private:

	std::string getRandomBotName()
	{
		int i = rand()%1000;
		std::stringstream ss;
		ss << std::noskipws;
		ss << "Bot ";
		ss << i;
		std::string botPseudo = ss.str();

		return botPseudo;
	}
	void SendChatToRandomClient()
	{
		std::string player;

		if (clientVect.size() == 0)
		{
			player = getRandomBotName();
		}
		else
		{
			int index = rand() % clientVect.size();

			player = clientVect.at(index);
		}

		ChatAPI::SendDirectChat(player, "hello " + player);
	}

	void SendChatToJoinedRoom()
	{
		if (joinedRoom == "")
			return;

		ChatAPI::SendRoomChat("hello room " + joinedRoom, joinedRoom);
	}

	void JoinRandomRoom()
	{
		if (roomsList.size() == 0)
			return;

		int index = rand() % roomsList.size();

		std::string roomName = roomsList.at(index);
		if(roomName == joinedRoom)
			return;

		ChatAPI::JoinRoom(roomName);
	}




};
