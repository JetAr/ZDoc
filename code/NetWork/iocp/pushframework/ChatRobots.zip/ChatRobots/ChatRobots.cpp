// ChatRobots.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "Bot.h"


typedef std::vector<Bot*> botVectT;

botVectT botVect;

bool getConfigFile( std::string& path );
void readConfig(std::string& strIniFile, Options_t& options);
void startBot();


Options_t globalOptions;

int _tmain(int argc, _TCHAR* argv[])
{
	std::string strIniFile;
	if (!getConfigFile(strIniFile)){
		cout << "Unable to find conf file" << endl;
		return false;
	}
	readConfig(strIniFile, globalOptions);

	//
	ChatAPI::initializeWinsock();
	wcout << L"Simulator started.."<<std::endl;



	//Connect at once phase :
	for (int i=0;i< globalOptions.nConnectAtOnce;i++)
	{
		startBot();
	}

	//Staged phase :
	int stagedPhaseDurationCounter = 0;
	while (stagedPhaseDurationCounter < globalOptions.stagedPhaseDuration)
	{
		Sleep(1000);
		for (int i=0;i< globalOptions.stagedConnectionPerSecond;i++)
		{
			startBot();
		}
		stagedPhaseDurationCounter++;
		//
	}

	wcout << L"Ready to quit : tape q";
	int ch;
	do 
	{
		ch = _getch();
		ch = toupper(ch);
	} while (ch !='Q');

	for (botVectT::iterator it = botVect.begin();
		it!= botVect.end();it++)
	{
		Bot* pBot = *it;

		//
		pBot->disconnect(false);
		delete pBot;
	}

	return 0;
}



void startBot()
{
	static int i = 0;
	i++;
	//forming unique pseudo :
	std::stringstream ss;
	ss << std::noskipws;
	ss << "Bot ";
	ss << i;
	std::string botPseudo = ss.str();

	Bot* pBot = new Bot(globalOptions);
	pBot->setLoginInfo(botPseudo);

	cout << "Connecting bot " << botPseudo.c_str() << std::endl;



	if (!pBot->connect(globalOptions.serverIP.c_str(), globalOptions.port))
	{
		wcout << L"Unable to connect bot " << i <<std::endl;
		delete pBot;
		return ;
	}
	else
		botVect.push_back(pBot);
}
void readConfig(std::string& strIniFile, Options_t& options)
{
	char hostIP[256];

	GetPrivateProfileStringA("server",  "hostIp", "127.0.0.1", hostIP, 256, strIniFile.c_str());
	options.serverIP = hostIP;
	options.port = GetPrivateProfileIntA("server",  "port", 2011, strIniFile.c_str());

	options.stayDuration = GetPrivateProfileIntA("connection",  "stayDuration", 40, strIniFile.c_str());
	options.stagedPhaseDuration = GetPrivateProfileIntA("connection",  "stagedPhaseDuration", 120, strIniFile.c_str());
	options.stagedConnectionPerSecond = GetPrivateProfileIntA("connection",  "stagedConnectionPerSecond", 1, strIniFile.c_str());
	options.nConnectAtOnce = GetPrivateProfileIntA("connection",  "connectAtOnce", 100, strIniFile.c_str());

	options.directChatDuration = GetPrivateProfileIntA("behavior",  "directChat", 1, strIniFile.c_str());
	options.directChatBulks = GetPrivateProfileIntA("behavior",  "directChatBulks", 10, strIniFile.c_str());
	options.replyDirectProb = GetPrivateProfileIntA("behavior",  "replyToDirect", 0, strIniFile.c_str());
	options.sendRoomChatDuration = GetPrivateProfileIntA("behavior",  "roomChat", -1, strIniFile.c_str());
	options.joinRoomDuration = GetPrivateProfileIntA("behavior",  "joinRoom", -1, strIniFile.c_str());
}
bool getConfigFile( std::string& path )
{
	char szPath[MAX_PATH];
	if( !GetModuleFileNameA( NULL, szPath, MAX_PATH ) )
		return 1;
	std::string strPath(szPath);
	std::string::size_type pos1 = strPath.rfind('\\');
	std::string::size_type pos2 = strPath.rfind('/');
	std::string::size_type pos = (pos1==-1) ? pos2 : (pos2==-1) ? pos1 : (max(pos1, pos2));
	szPath[pos] = '\0';
	std::string strModuleDirectory(szPath);

	path = strModuleDirectory + "\\ChatRobots.ini";

	return true;
}