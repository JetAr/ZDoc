// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

#include <conio.h>
#include <ctype.h>


// TODO: reference additional headers your program requires here
#include <string>
#include <xstring>
#include <sstream>
#include <iosfwd>
#include <vector>
#include <map>

#include <iostream>
#include <fstream>

// TODO: reference additional headers your program requires here
#include <atlcomtime.h>


using namespace std;

#include <TCPSocketInc.h>
#include <ChatAPI.h>


