#include "StdAfx.h"
#include "ClientProtocol.h"

#include "ProtobufPacket.h"

CClientProtocol::CClientProtocol(void)
{
}

CClientProtocol::~CClientProtocol(void)
{
}

PushFramework::IncomingPacket* CClientProtocol::createIncomingPacketFromServiceId( int serviceId )
{
	switch (serviceId)
	{
	case LoginResponseID:
		return new ProtobufPacket<LoginResponse>(serviceId);
		break;
	case DataInfoResponseID:
		return new ProtobufPacket<DataInfoResponse>(serviceId);
		break;
	default:
		return NULL;
		break;
	}
}
