#pragma once

class CClientProtocol : public ExampleProtocol
{
public:
	CClientProtocol(void);
	~CClientProtocol(void);

	PushFramework::IncomingPacket* createIncomingPacketFromServiceId(int serviceId);
};
