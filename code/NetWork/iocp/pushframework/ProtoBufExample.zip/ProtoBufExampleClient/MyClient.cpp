#include "StdAfx.h"
#include "MyClient.h"

#include "ClientProtocol.h"
#include "ProtobufPacket.h"
#include "ResponseHandlers.h"

CMyClient::CMyClient(void)
{
	setProtocol(new CClientProtocol);

	registerHandler(LoginResponseID, new LoginResponseHandler(this));
	registerHandler(DataInfoResponseID, new DataInfoResponseHandler(this));
}

CMyClient::~CMyClient(void)
{
}

bool CMyClient::Logout()
{
	ProtobufPacket<LogoutRequest> request(LogoutRequestID);
	sendRequest(&request);
	disconnect(true);


	return true;
}

bool CMyClient::RequestDataInfo( int id )
{
	ProtobufPacket<DataInfoRequest> request(DataInfoRequestID);
	//
	request.getData().set_id(id);
	return sendRequest(&request);
}

void CMyClient::onConnected( bool bResult )
{
	if (bResult){
		cout << "succesfully connected"  << std::endl;

		ProtobufPacket<LoginRequest> request(LoginRequestID);

		sendRequest(&request);
	}
	else
		cout << "failed to connect" << std::endl;
}

void CMyClient::onConnectionClosed( bool bPeerClose )
{
	cout << "connection closed"  << std::endl;
}
