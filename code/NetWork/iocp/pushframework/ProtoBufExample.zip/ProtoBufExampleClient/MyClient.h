#pragma once

class CMyClient : public TCPSocket
{
public:
	CMyClient(void);
	~CMyClient(void);
	//
	bool Logout();
	bool RequestDataInfo(int id);
	void OnLoginResponse(bool result)
	{
		cout << (result ? "login accepted" : "login refused") << std::endl;
	}
	void OnDataInfoResponse(int result, std::string str)
	{
		cout << "item details : " << str << std::endl;
	}
protected:
	virtual void onConnected(bool bResult);
	virtual void onConnectionClosed(bool bPeerClose);
};
