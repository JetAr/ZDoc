// ProtoBufExampleClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "MyClient.h"
char hostAddress[] = "127.0.0.1";
unsigned int uPort = 2010;

int _tmain(int argc, _TCHAR* argv[])
{
	TCPSocket::initializeWinsock();


	CMyClient client;

	cout << "Connecting " << std::endl;

	if (!client.connect(hostAddress, uPort))
	{
		cout << "Unable to connect " << std::endl;
	}
	cout << "Put Q or q to quit" << std::endl;
	int ch;

	do 
	{
		ch = _getch();
		ch = toupper(ch);

		if (ch == 'C')
		{
			client.RequestDataInfo(1);
		}
	} while (ch !='Q');



	client.Logout();
	
	return 0;
}

