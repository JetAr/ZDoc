#pragma once

#include "MyClient.h"

class LoginResponseHandler : public ResponseHandler
{
public:
	LoginResponseHandler(CMyClient* pSession)
	{
		this->pSession = pSession;
	}
	~LoginResponseHandler(){}
	virtual void handleResponse(PushFramework::IncomingPacket& packet)
	{
		ProtobufPacket<LoginResponse>& response = (ProtobufPacket<LoginResponse>&) packet;

		pSession->OnLoginResponse(response.getData().result());
	}
private:
	CMyClient* pSession;
};


//


class DataInfoResponseHandler : public ResponseHandler
{
public:
	DataInfoResponseHandler(CMyClient* pSession)
	{
		this->pSession = pSession;
	}
	~DataInfoResponseHandler(){}
	virtual void handleResponse(PushFramework::IncomingPacket& packet)
	{
		ProtobufPacket<DataInfoResponse>& response = (ProtobufPacket<DataInfoResponse>&) packet;

		pSession->OnDataInfoResponse(response.getData().result(), response.getData().description());
	}
private:
	CMyClient* pSession;
};
