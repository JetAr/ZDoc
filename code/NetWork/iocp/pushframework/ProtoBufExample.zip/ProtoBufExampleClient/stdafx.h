// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"



#include <stdio.h>
#include <tchar.h>

#include <conio.h>
#include <ctype.h>
#include <iostream>
#include <fstream>


#include <string>
#include <xstring>
#include <map>
#include <vector>
#include <set>
using namespace std;

#include <PushFrameworkInc.h>
#include <TCPSocketInc.h>
#include <ProtoBufExampleProtocolInc.h>
using namespace gprotoexample;