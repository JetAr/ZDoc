#include "StdAfx.h"
#include "ExampleProtocol.h"

#define SignatureStart 16018
#define SignatureEnd 16108

#include "ProtobufPacket.h"

#include "requests.pb.h"
#include "responses.pb.h"

using namespace gprotoexample;


ExampleProtocol::ExampleProtocol(void)
{
}

ExampleProtocol::~ExampleProtocol(void)
{
}

int ExampleProtocol::encodeOutgoingPacket( PushFramework::OutgoingPacket& packet )
{
	ProtobufPacketImpl& gPacket = (ProtobufPacketImpl&) packet;

	return gPacket.Encode() ? PushFramework::Protocol::Success : PushFramework::Protocol::eEncodingFailure;
}

int ExampleProtocol::frameOutgoingPacket( PushFramework::OutgoingPacket& packet, PushFramework::DataBuffer& buffer, unsigned int& nWrittenBytes )
{
	ProtobufPacketImpl& gPacket = (ProtobufPacketImpl&) packet;

	nWrittenBytes = 6 + gPacket.getEncodedStream()->size() + 2;

	if(nWrittenBytes > buffer.getRemainingSize())
		return PushFramework::Protocol::eInsufficientBuffer;
	//
	unsigned int sStart = SignatureStart;
	unsigned int packetLen = gPacket.getEncodedStreamSize() + 8;
	unsigned int commandID = gPacket.getServiceId();
	unsigned int sEnd = SignatureEnd;

	buffer.Append((char*) &sStart, 2);
	buffer.Append((char*)&packetLen, 2);
	buffer.Append((char*)&commandID, 2);

	buffer.Append((char*)gPacket.getEncodedStream()->c_str(), gPacket.getEncodedStreamSize());

	buffer.Append((char*)&sEnd, 2);


	return PushFramework::Protocol::Success;
	
}

/*
int ExampleProtocol::serializeOutgoingPacket( PushFramework::OutgoingPacket* pPacket, char* pBuffer, unsigned int uBufferSize, unsigned int& uWrittenBytes )
{
	ProtobufPacketImpl* pProtobufPacket = (ProtobufPacketImpl*) pPacket;
	if(!pPacket->Encode())
		return PushFramework::Protocol::eEncodingFailure;

	if ( (pProtobufPacket->getEncodedStream()->size() + 8) > uBufferSize)
		return PushFramework::Protocol::eInsufficientBuffer;



	unsigned int sStart = SignatureStart;
	unsigned int packetLen = pProtobufPacket->getEncodedStreamSize() + 8;
	unsigned int commandID = pProtobufPacket->getServiceId();
	unsigned int sEnd = SignatureEnd;

	for (int i=0;i<2;i++)
	{
		pBuffer[i] = *((BYTE*)(&sStart)+i);
		pBuffer[i+2] = *((BYTE*)(&packetLen)+i);
		pBuffer[i+4] = *((BYTE*)(&commandID)+i);
	}

	CopyMemory(pBuffer + 6, pProtobufPacket->getEncodedStream()->c_str(), pProtobufPacket->getEncodedStreamSize());

	for (int i=0;i<2;i++)
		pBuffer[packetLen-2+i] = *((BYTE*)(&sEnd)+i);

	uWrittenBytes = 8 + pProtobufPacket->getEncodedStreamSize();

	return PushFramework::Protocol::Success;

	return 0;
}

*/
int ExampleProtocol::tryDeframeIncomingPacket( PushFramework::DataBuffer& buffer, PushFramework::IncomingPacket*& pPacket, int& serviceId, unsigned int& nExtractedBytes )
{
	if(buffer.GetDataSize() < 8)
		return PushFramework::Protocol::eIncompletePacket;

	char* pBuffer = buffer.GetBuffer();

	unsigned int sStart = 0;
	unsigned int packetLen = 0;
	serviceId = 0;
	unsigned int sEnd = 0;

	for (int i=0;i<2;i++)
	{
		*((BYTE*)(&sStart)+i)=pBuffer[i];
		*((BYTE*)(&packetLen)+i)=pBuffer[i+2];
		*((BYTE*)(&serviceId)+i)=pBuffer[i+4];
	}

	if (sStart!=SignatureStart)
		return PushFramework::Protocol::eCorruptPacket;

	if (packetLen > buffer.GetDataSize())
		return PushFramework::Protocol::eIncompletePacket;

	for (int i=0;i<2;i++)
		*((BYTE*)(&sEnd)+i)=pBuffer[packetLen-2+i];

	if(sEnd!=SignatureEnd)
		return PushFramework::Protocol::eCorruptPacket;

	char* pData = pBuffer + 6;
	unsigned int dataSize = packetLen - 8;

	nExtractedBytes = packetLen;

	pPacket = createIncomingPacketFromServiceId(serviceId);
	if(pPacket==NULL)
		return PushFramework::Protocol::eUndefinedFailure;

	if(!pPacket->Decode(pData, dataSize))
	{
		disposeIncomingPacket(pPacket);
		return PushFramework::Protocol::eDecodingFailure;
	}
	return PushFramework::Protocol::Success;
}


/*
int ExampleProtocol::tryDeframeIncomingPacket( char* pBuffer, unsigned int uBufferSize, unsigned int& serviceId, PushFramework::IncomingPacket*& lpMessage, unsigned int& uExtractedBytes )
{
	if(uBufferSize < 8)
		return PushFramework::Protocol::eIncompletePacket;

	unsigned int sStart = 0;
	unsigned int packetLen = 0;
	serviceId = 0;
	unsigned int sEnd = 0;

	for (int i=0;i<2;i++)
	{
		*((BYTE*)(&sStart)+i)=pBuffer[i];
		*((BYTE*)(&packetLen)+i)=pBuffer[i+2];
		*((BYTE*)(&serviceId)+i)=pBuffer[i+4];
	}

	if (sStart!=SignatureStart)
		return PushFramework::Protocol::eCorruptPacket;

	if (packetLen > uBufferSize)
		return PushFramework::Protocol::eIncompletePacket;

	for (int i=0;i<2;i++)
		*((BYTE*)(&sEnd)+i)=pBuffer[packetLen-2+i];

	if(sEnd!=SignatureEnd)
		return PushFramework::Protocol::eCorruptPacket;

	char* pData = pBuffer + 6;
	unsigned int dataSize = packetLen - 8;

	PushFramework::IncomingPacket* pPacket = createIncomingPacketFromServiceId(serviceId);
	if(pPacket==NULL)
		return PushFramework::Protocol::eUndefinedFailure;

	if(!pPacket->Decode(pData, dataSize))
	{
		disposeIncomingPacket(pPacket);
		return PushFramework::Protocol::eDecodingFailure;
	}

	lpMessage = pPacket;
	uExtractedBytes = packetLen;
	return PushFramework::Protocol::Success;
}

*/
int ExampleProtocol::decodeIncomingPacket( PushFramework::IncomingPacket* pPacket, int& serviceId )
{
	return PushFramework::Protocol::Success;
}

void ExampleProtocol::disposeOutgoingPacket( PushFramework::OutgoingPacket* pPacket )
{
	delete pPacket;
}

void ExampleProtocol::disposeIncomingPacket( PushFramework::IncomingPacket* pPacket )
{
	delete pPacket;
}



