#pragma once

#include "ProtoBufExampleProtocol.h"

typedef enum
{
	LoginRequestID = 1,
	DataInfoRequestID,
	LogoutRequestID,
	LoginResponseID,
	DataInfoResponseID
};

class PROTOBUFEXAMPLEPROTOCOL_API ExampleProtocol: public PushFramework::Protocol
{
public:
	ExampleProtocol(void);
	~ExampleProtocol(void);

/*
	virtual int serializeOutgoingPacket(PushFramework::OutgoingPacket* pPacket, char* pBuffer, unsigned int uBufferSize, unsigned int& uWrittenBytes);
	virtual int tryDeframeIncomingPacket(char* pBuffer, unsigned int uBufferSize, unsigned int& serviceId, PushFramework::IncomingPacket*& lpMessage, unsigned int& uExtractedBytes);
*/
	virtual void disposeOutgoingPacket(PushFramework::OutgoingPacket* pPacket);
	virtual void disposeIncomingPacket(PushFramework::IncomingPacket* pPacket);
protected:
	virtual PushFramework::IncomingPacket* createIncomingPacketFromServiceId(int serviceId) = 0;

protected:
	virtual int encodeOutgoingPacket(PushFramework::OutgoingPacket& packet);
	virtual int frameOutgoingPacket(PushFramework::OutgoingPacket& packet, PushFramework::DataBuffer& buffer, unsigned int& nWrittenBytes);

	//
	virtual int tryDeframeIncomingPacket(PushFramework::DataBuffer& buffer, PushFramework::IncomingPacket*& pPacket, int& serviceId, unsigned int& nExtractedBytes);
	virtual int decodeIncomingPacket(PushFramework::IncomingPacket* pPacket, int& serviceId);

};
