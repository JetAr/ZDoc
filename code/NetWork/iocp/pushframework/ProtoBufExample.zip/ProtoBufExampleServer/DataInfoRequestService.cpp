#include "StdAfx.h"
#include "DataInfoRequestService.h"

#include "ProtobufPacket.h"
#include "ExampleClient.h"

CDataInfoRequestService::CDataInfoRequestService(void)
{
}

CDataInfoRequestService::~CDataInfoRequestService(void)
{
}

void CDataInfoRequestService::handle( ClientKey clientKey, PushFramework::IncomingPacket* pRequest )
{

	cout << "inforequest" << std::endl;
	ExampleClient* pClient = (ExampleClient*) getServer()->getClientFactory()->getClient(clientKey);
	if(!pClient)
		return;

	ProtobufPacket<DataInfoRequest>* pDataInfoRequest = (ProtobufPacket<DataInfoRequest>*) pRequest;

	
	ProtobufPacket<DataInfoResponse> response(DataInfoResponseID);
	response.getData().set_id(pDataInfoRequest->getData().id());
	response.getData().set_result(DataInfoResponse_ResultType_InfoFound);
	response.getData().set_description("this is a description");
	//
	pClient->pushPacket(&response);


	getServer()->getClientFactory()->returnClient(clientKey);
}
