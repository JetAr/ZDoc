#pragma once

class CDataInfoRequestService : public PushFramework::Service
{
public:
	CDataInfoRequestService(void);
	~CDataInfoRequestService(void);
protected:
	virtual void handle(ClientKey clientKey, PushFramework::IncomingPacket* pRequest);
};
