#include "StdAfx.h"
#include "ExampleClient.h"

ExampleClient::ExampleClient(std::string pseudo)
{
	this->pseudo = pseudo;
}

ExampleClient::~ExampleClient(void)
{
}

const char* ExampleClient::getKey()
{
	return pseudo.c_str();
}
