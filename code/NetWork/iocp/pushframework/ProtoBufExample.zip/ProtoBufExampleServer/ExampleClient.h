#pragma once

class ExampleClient : public PushFramework::Client
{
public:
	ExampleClient(std::string pseudo);
	~ExampleClient(void);
	virtual const char* getKey();
private:
	std::string pseudo;
};
