#include "StdAfx.h"
#include "ExampleClientFactory.h"

#include "ExampleClient.h"
#include "ProtobufPacket.h"


ExampleClientFactory::ExampleClientFactory(void)
{
}

ExampleClientFactory::~ExampleClientFactory(void)
{
}

PushFramework::OutgoingPacket* ExampleClientFactory::onNewConnection( void*& lpContext )
{
	return NULL; // We do'nt challenge client.
}

void ExampleClientFactory::onBeforeDisposeClient( PushFramework::Client* pClient )
{
	//Nothing to be done.
}

void ExampleClientFactory::onClientConnected( ClientKey key )
{
	ExampleClient* pClient = (ExampleClient*) getClient(key);
	if(!pClient)
		return;

	//
	ProtobufPacket<LoginResponse> response(LoginResponseID);
	response.getData().set_result(true);
	//

	pClient->pushPacket(&response);

	returnClient(key);
}

void ExampleClientFactory::disposeClient( PushFramework::Client* pClient )
{
	delete pClient;
}

int ExampleClientFactory::onFirstRequest( PushFramework::IncomingPacket& request, void* lpContext, PushFramework::Client*& lpClient, PushFramework::OutgoingPacket*& lpPacket )
{
	cout << "on first request" << std::endl;
	ProtobufPacket<LoginRequest>& loginRequest= (ProtobufPacket<LoginRequest>&) request;

	static int clientId = 0;
	clientId++;

	char pPseudo[4];
	sprintf_s(pPseudo, 4, "%d", clientId);

	ExampleClient* pClient = new ExampleClient(pPseudo);
	lpClient = pClient;


	return PushFramework::ClientFactory::CreateClient;
}
