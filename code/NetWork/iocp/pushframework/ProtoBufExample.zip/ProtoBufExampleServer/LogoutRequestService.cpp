#include "StdAfx.h"
#include "LogoutRequestService.h"
#include "ExampleClient.h"
#include "ProtobufPacket.h"


CLogoutRequestService::CLogoutRequestService(void)
{
}

CLogoutRequestService::~CLogoutRequestService(void)
{
}

void CLogoutRequestService::handle( ClientKey clientKey, PushFramework::IncomingPacket* pRequest )
{
	ExampleClient* pClient = (ExampleClient*) getServer()->getClientFactory()->getClient(clientKey);
	if(!pClient)
		return;

	ProtobufPacket<LogoutRequest>* pLogoutRequest = (ProtobufPacket<LogoutRequest>*) pRequest;
	pClient->disconnect(false);

	getServer()->getClientFactory()->returnClient(clientKey);
}
