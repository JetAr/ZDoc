#pragma once

class CLogoutRequestService : public PushFramework::Service
{
public:
	CLogoutRequestService(void);
	~CLogoutRequestService(void);
protected:
	virtual void handle(ClientKey clientKey, PushFramework::IncomingPacket* pRequest);

};
