// ProtoBufExampleServer.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "ExampleClientFactory.h"
#include "DataInfoRequestService.h"
#include "LogoutRequestService.h"

#include "ServerProtocol.h"




int _tmain(int argc, _TCHAR* argv[])
{
	PushFramework::Server server;


	server.setServerInfos("Example server");

	server.registerService(DataInfoRequestID, new CDataInfoRequestService, "dataInfo");
	server.registerService(LogoutRequestID, new CLogoutRequestService, "logout");


	server.setClientFactory(new ExampleClientFactory);

	server.setLoginExpiryDuration(10);
	server.setProtocol(new CServerProtocol);

	server.createListener(2010);


	



	try
	{
		server.start(true);
	}
	catch (std::exception& e)
	{
		cout << "Failed to start server. Exception : " << e.what() << std::endl;
		return 0;
	}

	

	int ch;

	do 
	{
		ch = _getch();
		ch = toupper(ch);
	} while (ch !='Q');


	

	server.stop();

	return 0;
}




