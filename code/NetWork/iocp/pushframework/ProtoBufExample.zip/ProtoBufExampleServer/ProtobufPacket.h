#pragma once


template<class T>
class ProtobufPacket : public ProtobufPacketImpl
{
public:
	ProtobufPacket(int serviceId)
		: ProtobufPacketImpl(serviceId, &data)
	{
		//
	}
	~ProtobufPacket()
	{
		//
	}
private:
	T data;
public:
	T& getData()
	{
		return data;
	}
};
