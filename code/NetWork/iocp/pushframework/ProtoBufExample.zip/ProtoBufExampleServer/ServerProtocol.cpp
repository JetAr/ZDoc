#include "StdAfx.h"
#include "ServerProtocol.h"

#include "ProtobufPacket.h"

CServerProtocol::CServerProtocol(void)
{
}

CServerProtocol::~CServerProtocol(void)
{
}

PushFramework::IncomingPacket* CServerProtocol::createIncomingPacketFromServiceId( int serviceId )
{
	switch (serviceId)
	{
	case LoginRequestID:
		return new ProtobufPacket<LoginRequest>(serviceId);
		break;
	case DataInfoRequestID:
		return new ProtobufPacket<DataInfoRequest>(serviceId);
		break;
	default:
		return NULL;
		break;
	}
}
