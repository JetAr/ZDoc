#pragma once

class CServerProtocol : public ExampleProtocol
{
public:
	CServerProtocol(void);
	~CServerProtocol(void);

	PushFramework::IncomingPacket* createIncomingPacketFromServiceId(int serviceId);
};
