/********************************************************************
	File :			BroadcastChannel.h
	Creation date :	2010/6/27
		
	License :			Copyright 2010 Ahmed Charfeddine, http://www.pushframework.com

				   Licensed under the Apache License, Version 2.0 (the "License");
				   you may not use this file except in compliance with the License.
				   You may obtain a copy of the License at
				
					   http://www.apache.org/licenses/LICENSE-2.0
				
				   Unless required by applicable law or agreed to in writing, software
				   distributed under the License is distributed on an "AS IS" BASIS,
				   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
				   See the License for the specific language governing permissions and
				   limitations under the License.
	
	
*********************************************************************/
#ifndef BroadcastChannel__INCLUDED
#define BroadcastChannel__INCLUDED

#pragma once

#include "..\include\PushFramework.h"

namespace PushFramework{

class BroadcastManagerImplBase;
class OutgoingPacket;
class Protocol;
	

class BroadcastChannel
{
public:
	BroadcastChannel(BroadcastManagerImplBase* pManager, std::string channelName, bool requireRegistration);
	~BroadcastChannel(void);
public:
	typedef double PacketHANDLE;


	void setMaxPackets(unsigned int maxPacket);

	void pushPacket(OutgoingPacket* pPacket, WStrKey killKey="", int objectCategory =0);
	void removePacket(WStrKey killKey="", int objectCategory =0);
	
	void subscribeClient(std::string clientKey);
	void unsubscribeClient(std::string clientKey);

	void disposePacket(PacketHANDLE hPacket, std::string clientKey, bool bSuccess = true);
	OutgoingPacket* getNextPacket(std::string clientKey, PacketHANDLE& hPacket);

	void disposeAllPackets();


private:
	BroadcastManagerImplBase* pManager;
	//
	std::string channelName;

	unsigned int maxPacket;
	bool requireRegistration;

	//
	PacketHANDLE nextPacketID;

	//Queue by handle
	typedef std::vector<PacketHANDLE> packetIDVectT;
	packetIDVectT packetIDVect;

	//Storage :
	typedef struct PacketInfo
	{
		OutgoingPacket* pPacket;
		unsigned int refCount;
		bool bWaitingForRemoval;
	}PacketInfo;
	typedef std::map<PacketHANDLE, PacketInfo*> packetMapByIDT;
	packetMapByIDT packetMapByID;

	//Access (for subsequent explicit deletion):
	typedef std::map<std::string, PacketHANDLE> packetMapByKeyT;
	typedef std::map<int, packetMapByKeyT*> packetMapByCategoryT;
	packetMapByCategoryT packetMapByCategory;

	//References :
	typedef std::map<std::string, PacketHANDLE> clientMapT;
	clientMapT clientMap;

	CRITICAL_SECTION cs;


	void storePacket(OutgoingPacket* pPacket, PacketHANDLE hPacket, WStrKey killKey="", int objectCategory =0);
	void killPacket(PacketHANDLE hPacket);
};

}
#endif // BroadcastChannel__INCLUDED

