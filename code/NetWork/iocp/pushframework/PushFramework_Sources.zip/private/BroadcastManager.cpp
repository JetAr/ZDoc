/********************************************************************
	File :			BroadcastManager.cpp
	Creation date :	2010/6/27
		
	License :			Copyright 2010 Ahmed Charfeddine, http://www.pushframework.com

				   Licensed under the Apache License, Version 2.0 (the "License");
				   you may not use this file except in compliance with the License.
				   You may obtain a copy of the License at
				
					   http://www.apache.org/licenses/LICENSE-2.0
				
				   Unless required by applicable law or agreed to in writing, software
				   distributed under the License is distributed on an "AS IS" BASIS,
				   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
				   See the License for the specific language governing permissions and
				   limitations under the License.
	
	
*********************************************************************/
#include "StdAfx.h"
#include "..\include\BroadcastManager.h"

#include "BroadcastManagerImpl.h"

namespace PushFramework{


BroadcastManager::BroadcastManager(void)
{
	pImpl = new BroadcastManagerImpl;
}

BroadcastManager::~BroadcastManager(void)
{
	delete pImpl;
}

void BroadcastManager::createChannel( WStrKey channelKey, unsigned int maxPacket, bool requireSubscription, unsigned int uPriority, unsigned int uPacketQuota )
{
	pImpl->createChannel(channelKey, maxPacket, requireSubscription, uPriority, uPacketQuota);
}

void BroadcastManager::removeChannel( WStrKey channelKey )
{
	pImpl->removeChannel(channelKey);
}

bool BroadcastManager::subscribeClient( ClientKey clientKey, WStrKey channelKey )
{
	return pImpl->subscribeClient(clientKey, channelKey);
}

bool BroadcastManager::unsubscribeClient( ClientKey clientKey, WStrKey channelKey )
{
	return pImpl->unsubscribeClient(clientKey, channelKey);
}

void BroadcastManager::pushPacket( OutgoingPacket* pPacket, WStrKey channelName, WStrKey killKey, int objectCategory )
{
	pImpl->pushPacket(pPacket, channelName, killKey, objectCategory);
}

void BroadcastManager::removePacket( WStrKey killKey, int objectCategory, WStrKey channelKey )
{
	pImpl->removePacket(killKey, objectCategory, channelKey);
}

void BroadcastManager::removeClient( ClientKey clientKey )
{
	pImpl->removeClient(clientKey);
}
}

