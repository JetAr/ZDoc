/********************************************************************
	File :			Channel.cpp
	Creation date :	2010/6/27
		
	License :			Copyright 2010 Ahmed Charfeddine, http://www.pushframework.com

				   Licensed under the Apache License, Version 2.0 (the "License");
				   you may not use this file except in compliance with the License.
				   You may obtain a copy of the License at
				
					   http://www.apache.org/licenses/LICENSE-2.0
				
				   Unless required by applicable law or agreed to in writing, software
				   distributed under the License is distributed on an "AS IS" BASIS,
				   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
				   See the License for the specific language governing permissions and
				   limitations under the License.
	
	
*********************************************************************/
#include "StdAfx.h"
#include "Channel.h"

#include "IOCPQueue.h"
#include "ServerImpl.h"

#include "Dispatcher.h"
#include "ServerStats.h"

#include "ScopedLock.h"

#include "..\include\ListenerOptions.h"


namespace PushFramework{


	CChannel::CChannel(ServerImpl* pServerImpl, ListenerOptions* pListenerOption)
{
	this->pServerImpl = pServerImpl;
	this->pListenerOption = pListenerOption;

	this->bReusable = bReusable;

	status = Free;

	oBuffer.Allocate(pListenerOption->uIntermediateSendBufferSize);
	inBuffer.Allocate(pListenerOption->uIntermediateReceiveBufferSize);

	m_byInBuffer = new BYTE[pListenerOption->uReadBufferSize];
	m_byOutBuffer = new BYTE[pListenerOption->uSendBufferSize];

	m_wsaInBuffer.buf = (char*)m_byInBuffer;
	m_wsaInBuffer.len = sizeof(m_byInBuffer);
	m_wsaOutBuffer.buf = (char*)m_byOutBuffer;
	m_wsaOutBuffer.len = sizeof(m_byOutBuffer);
	pReadOverlap=new OVERLAPPEDPLUS(IORead);
	pWriteOverlap=new OVERLAPPEDPLUS(IOWrite);
	
	::InitializeCriticalSection(&csLock);	
}

CChannel::~CChannel(void)
{
	delete [] m_byOutBuffer;
	delete [] m_byInBuffer;

	if(pReadOverlap)
		delete pReadOverlap;
	if(pWriteOverlap)
		delete pWriteOverlap;

	::DeleteCriticalSection(&csLock);
}

int CChannel::getStatus()
{
	return status;
}

CChannel::Key& CChannel::getKey()
{
	return key;
}

ULONG& CChannel::getRefCount()
{
	return refCount;
}

COleDateTimeSpan CChannel::getLifeDuration()
{
	return COleDateTime::GetCurrentTime() - dtCreationTime;
}

ULONG& CChannel::getPostedIOs()
{
	return m_NumIOs;
}

bool CChannel::PostReceive()
{
	ScopedLock lock(csLock);
	if (status < Connected)
	{
		return true;
	}

	ULONG	ulFlags = MSG_PARTIAL;
	DWORD dwIoSize;

	UINT nRetVal = WSARecv(socket, 
		&m_wsaInBuffer,
		1,
		&dwIoSize, 
		&ulFlags,
		&pReadOverlap->m_ol, 
		NULL);

	if ( nRetVal == SOCKET_ERROR && WSAGetLastError() != WSA_IO_PENDING) 
	{
		//CLoggingFacilities::doLoggingByArgList("WSARecv Failed %S", CUtilities::getSystemError().c_str());
		return false;
	}
	::InterlockedIncrement ( (long*)&m_NumIOs );
	return true;
}

int CChannel::ReadReceivedBytes( DWORD dwIoSize )
{
	ScopedLock lock(csLock);

	::InterlockedDecrement ( (long*)&m_NumIOs );
	if(status==WaitingForAllIOs)
	{
		if (m_NumIOs==0)
			status=Released;
		return status;
	}

	if(dwIoSize==0)
		return status;

	inBuffer.Append((char*)m_byInBuffer,dwIoSize);
	return status;
}



bool CChannel::PushPacket( OutgoingPacket* pPacket )
{
	ScopedLock lock(csLock);
	if (status < Connected)
	{
		return true;
	}

	unsigned int uWrittenBytes = 0;

	Protocol* pProtocol = pListenerOption->pProtocol;

	int iResult = pProtocol->serializeOutgoingPacket(*pPacket, oBuffer, uWrittenBytes);
	//int iResult = pProtocol->serializeOutgoingPacket(pPacket, oBuffer.GetBuffer()+ oBuffer.GetDataSize(), oBuffer.getRemainingSize(),uWrittenBytes);

	if (iResult!=Protocol::Success)
	{
		pServerImpl->getStats()->addToCumul(ServerStats::BandwidthRejection, uWrittenBytes);
		return false;
	}

	pServerImpl->getStats()->addToCumul(ServerStats::BandwidthOutstanding, uWrittenBytes);
	std::string serviceName;
	if (pServerImpl->getDispatcher()->getCurrentService(serviceName))
	{
		pServerImpl->getStats()->addToDistribution(ServerStats::BandwidthOutboundVolPerRequest, serviceName, uWrittenBytes);
	}

	//oBuffer.GrowSize(uWrittenBytes);

	if (!bWriteInProgress)
	{
		return WriteBytes();
	}
	return true;
}
bool CChannel::WriteBytes()
{
	DWORD dwSent;
	bWriteInProgress=TRUE;
	DWORD dwToPick=min(pListenerOption->uSendBufferSize,oBuffer.GetDataSize());

	CopyMemory(m_wsaOutBuffer.buf,oBuffer.GetBuffer(),dwToPick);


	m_wsaOutBuffer.len=dwToPick;
	ULONG	ulFlags = MSG_PARTIAL;

	UINT nRetVal = WSASend(socket, 
		&m_wsaOutBuffer,
		1,
		&dwSent, 
		ulFlags,
		&pWriteOverlap->m_ol, 
		NULL);
	if ( nRetVal == SOCKET_ERROR && WSAGetLastError() != WSA_IO_PENDING) 
	{
		return false;
	}

	::InterlockedIncrement ( (long*)&m_NumIOs );
	return true;
}

int CChannel::OnSendCompleted( DWORD dwIoSize, bool& bIsBufferIdle )
{
	ScopedLock lock(csLock);

	::InterlockedDecrement ( (long*)&m_NumIOs );
	if(status==WaitingForAllIOs)
	{
		if (m_NumIOs==0)
			status=Released;
		return status;
	}

	oBuffer.Pop(dwIoSize);

	bIsBufferIdle = oBuffer.GetDataSize()==0;
	if (bIsBufferIdle)
	{
		if (status==WaitingForWrite )
		{
			CloseSocket();
		}
		else{
			bWriteInProgress = FALSE;
		}
		return status;
	}

	WriteBytes();
	return status;
}

void CChannel::Close( bool bWaitForSendsToComplete )
{
	ScopedLock lock(csLock);

	if (status < Connected)
	{
		return;
	}

	//Either connected or attached :
	if (bWaitForSendsToComplete)
	{
		if (oBuffer.GetDataSize() == 0)
		{
			CloseSocket();
		}
		else
			status = WaitingForWrite;
	}
	else
	{
		CloseSocket();
	}
}

void CChannel::CloseSocket()
{
	closesocket( socket );
	/*CancelIo((HANDLE)socket);
	
		while (!HasOverlappedIoCompleted((LPOVERLAPPED)pReadOverlap)) 
				Sleep(0);
			while (!HasOverlappedIoCompleted((LPOVERLAPPED)pWriteOverlap)) 
				Sleep(0);*/
		
	//The overlapped structure are safe to free when only the posted i/o has
	//completed. (resetValues does the freeing).

	status = WaitingForAllIOs;
	if (m_NumIOs==0)
	{
		status = Released;
	}
}

std::string CChannel::getClient()
{
	return clientKey;
}


void CChannel::saveContext( void* lpContext )
{
	this->lpContext = lpContext;
}

void* CChannel::getContext()
{
	return lpContext;
}

DataBuffer& CChannel::GetReceiveBuffer()
{
	return inBuffer;
}

void CChannel::attachToClient( const char* clientKey )
{
	this->clientKey = clientKey;
	status = Attached;
}

bool CChannel::isObserverChannel()
{
	return bIsObserver;
}

UINT CChannel::getPeerPort()
{
	return rPeerPort;
}

std::string CChannel::getPeerIP()
{
	return rPeerIP;
}

void CChannel::initialize( SOCKET s, SOCKADDR_IN address, bool bIsObserver )
{
	socket = s;

	rPeerPort = address.sin_port;
	rPeerIP = inet_ntoa(address.sin_addr);

	status = Connected;

	m_NumIOs=0;

	static Key dwKeyCount = 1;
	key = dwKeyCount++;

	refCount = 0;

	dtCreationTime = COleDateTime::GetCurrentTime();


	bWriteInProgress = FALSE;


	this->bIsObserver = bIsObserver;
}

void CChannel::unintialize()
{
	status = Free;
}

bool CChannel::isReusable()
{
	return bReusable;
}

Protocol* CChannel::getProtocol()
{
	return pListenerOption->pProtocol;
}

}
