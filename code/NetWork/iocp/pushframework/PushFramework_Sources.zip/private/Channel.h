/********************************************************************
	File :			Channel.h
	Creation date :	2010/6/27
		
	License :			Copyright 2010 Ahmed Charfeddine, http://www.pushframework.com

				   Licensed under the Apache License, Version 2.0 (the "License");
				   you may not use this file except in compliance with the License.
				   You may obtain a copy of the License at
				
					   http://www.apache.org/licenses/LICENSE-2.0
				
				   Unless required by applicable law or agreed to in writing, software
				   distributed under the License is distributed on an "AS IS" BASIS,
				   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
				   See the License for the specific language governing permissions and
				   limitations under the License.
	
	
*********************************************************************/
#ifndef Channel__INCLUDED
#define Channel__INCLUDED

#pragma once

#include "..\include\DataBuffer.h"
#include "..\include\Protocol.h"

#include "Overlap.h"

namespace PushFramework{



class ServerImpl;
struct ListenerOptions;

class CChannel
{
public:
	CChannel(ServerImpl* pServerImpl, ListenerOptions* pListenerOption);
	~CChannel();
	
	void initialize(SOCKET s, SOCKADDR_IN address, bool bIsObserver);
	void unintialize();
	Protocol* getProtocol();
private:
	bool bIsObserver;
	ListenerOptions* pListenerOption;
public:
	bool isObserverChannel();
	typedef unsigned int Key;
	typedef enum
	{
		Free = -1,
		WaitingForWrite =0,
		WaitingForAllIOs,
		Released,
		Connected,
		Attached,		
	};
	Key& getKey();
	int getStatus();
	ULONG& getRefCount();
	ULONG& getPostedIOs();
	COleDateTimeSpan getLifeDuration();
	std::string getClient();
	UINT getPeerPort();
	std::string getPeerIP();
	bool isReusable();
private:
	Key key; //address in the factory container.
	bool bReusable;//channel belongs to pool.
	ULONG refCount;//threads usage
	int status;//status
	ULONG      m_NumIOs;	// number of IOs currently posted
	COleDateTime dtCreationTime; 
	CRITICAL_SECTION csLock;
	std::string clientKey;
public:
	void Close(bool bWaitForSendsToComplete);
	bool PostReceive();
	int ReadReceivedBytes(DWORD dwIoSize);
	bool PushPacket(OutgoingPacket* pPacket);
	int OnSendCompleted(DWORD dwIoSize, bool& bIsBufferIdle);
	DataBuffer& GetReceiveBuffer();
private:
	DataBuffer inBuffer;
	//operation read buffer
	WSABUF	m_wsaInBuffer;
	BYTE *m_byInBuffer;//buffer passed for each read op
	OVERLAPPEDPLUS *pReadOverlap;

	WSABUF m_wsaOutBuffer;
	BYTE *m_byOutBuffer;//Buffer passed for each write op
	OVERLAPPEDPLUS *pWriteOverlap;
	DataBuffer oBuffer;
	BOOL bWriteInProgress;

private:
	SOCKET socket;
	UINT rPeerPort;
	std::string rPeerIP;

	bool WriteBytes();
	void CloseSocket();

private:
	void* lpContext;
public:
	void saveContext(void* lpContext);
	void* getContext();
	void attachToClient(const char* clientKey);
private:
	ServerImpl* pServerImpl;
};

}

#endif // Channel__INCLUDED
