/********************************************************************
	File :			ChannelPushInfo.h
	Creation date :	2010/6/27
		
	License :			Copyright 2010 Ahmed Charfeddine, http://www.pushframework.com

				   Licensed under the Apache License, Version 2.0 (the "License");
				   you may not use this file except in compliance with the License.
				   You may obtain a copy of the License at
				
					   http://www.apache.org/licenses/LICENSE-2.0
				
				   Unless required by applicable law or agreed to in writing, software
				   distributed under the License is distributed on an "AS IS" BASIS,
				   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
				   See the License for the specific language governing permissions and
				   limitations under the License.
	
	
*********************************************************************/
#ifndef ChannelPushInfo__INCLUDED
#define ChannelPushInfo__INCLUDED

#pragma once

namespace PushFramework{
class ChannelGroupPushInfo;

class ChannelPushInfo
{
public:

	ChannelPushInfo(std::string channelName, unsigned int uPacketQuota)
	{
		this->channelName = channelName;
		this->uPacketQuota = uPacketQuota;
		pNext = NULL;
	}

	~ChannelPushInfo(void)
	{
		delete pNext;
	}

public:

	std::string channelName;
	unsigned int uPacketQuota;
	ChannelPushInfo* pNext;
	ChannelGroupPushInfo* pParentGroup;

};

class ChannelGroupPushInfo
{
public:

	ChannelGroupPushInfo(unsigned int uPriority)
	{
		this->uPriority = uPriority;
		this->pItemList = NULL;
		pNextGroup = NULL;
	}
	~ChannelGroupPushInfo()
	{
		delete pItemList;
		delete pNextGroup;
	}

	void insertChannelInfo(ChannelPushInfo* pChannelInfo)
	{
		pChannelInfo->pParentGroup = this;

		//
		if (pItemList == NULL){
			pItemList = pChannelInfo;
			return;
		}
		
		ChannelPushInfo* pBefore = NULL;
		ChannelPushInfo* pAfter = pItemList;

		while(pAfter!=NULL)
		{
			if (pChannelInfo->uPacketQuota >= pAfter->uPacketQuota)
			{
				break;
			}
			else
			{
				pBefore = pAfter;
				pAfter = pAfter->pNext;
			}
		}

		if (pAfter == NULL)
		{
			pBefore->pNext = pChannelInfo;
		}
		else
		{
			pChannelInfo->pNext = pAfter;

			if (pBefore)
				pBefore->pNext = pChannelInfo;
			else
				pItemList = pChannelInfo;
		}
	}

public:

	unsigned int uPriority;
	ChannelPushInfo* pItemList;
	ChannelGroupPushInfo* pNextGroup;

};


class ClientSink
{
public:
	ClientSink()
	{
		nSentPackets = 0;
		pCurrentSinkChannel = NULL;
	}
	~ClientSink()
	{
		
	}

public:

	unsigned int nSentPackets;
	ChannelPushInfo* pCurrentSinkChannel;

};

}
#endif // ChannelPushInfo__INCLUDED

