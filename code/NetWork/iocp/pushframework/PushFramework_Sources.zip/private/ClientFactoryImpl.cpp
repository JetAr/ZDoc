/********************************************************************
	File :			ClientFactoryImpl.cpp
	Creation date :	2010/6/27
		
	License :			Copyright 2010 Ahmed Charfeddine, http://www.pushframework.com

				   Licensed under the Apache License, Version 2.0 (the "License");
				   you may not use this file except in compliance with the License.
				   You may obtain a copy of the License at
				
					   http://www.apache.org/licenses/LICENSE-2.0
				
				   Unless required by applicable law or agreed to in writing, software
				   distributed under the License is distributed on an "AS IS" BASIS,
				   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
				   See the License for the specific language governing permissions and
				   limitations under the License.
	
	
*********************************************************************/
#include "StdAfx.h"
#include "ClientFactoryImpl.h"


#include "..\include\Client.h"
#include "..\include\ClientFactory.h"
#include "ClientImpl.h"
#include "ServerImpl.h"
#include "ServerStats.h"
#include "..\include\BroadcastManager.h"
#include "BroadcastManagerImpl.h"
#include "Dispatcher.h"

#include "ScopedLock.h"


namespace PushFramework{




ClientFactoryImpl::ClientFactoryImpl(ClientFactory* pFacade)
{
	this->pFacade = pFacade;
	::InitializeCriticalSection(&cs);
}

ClientFactoryImpl::~ClientFactoryImpl(void)
{
	for (clientMapT::iterator it = clientMap.begin();it!=clientMap.end();it++)
	{
		Client* pClient = it->second;
		pFacade->disposeClient(pClient);
	}
	::DeleteCriticalSection(&cs);
}

Client* ClientFactoryImpl::tryAddClient( Client* pClient )
{
	std::string key(pClient->getKey());
	ScopedLock csLock(cs);
	//
	clientMapT::iterator it = clientMap.find(key);
	if(it!=clientMap.end()){
		Client* pExistingClient = it->second;
		pExistingClient->pImpl->getRefCount()++;
		return pExistingClient;
	}
	clientMap[key] = pClient;
	return NULL;
}

void ClientFactoryImpl::EnterContainer()
{
	::EnterCriticalSection(&cs);
	curIt = clientMap.begin();
}

bool ClientFactoryImpl::HasNext()
{
	return curIt!=clientMap.end();
}

Client* ClientFactoryImpl::GetNext()
{
	Client* pClient = curIt->second;
	curIt++;
	return pClient;
}

void ClientFactoryImpl::LeaveContainer()
{
	::LeaveCriticalSection(&cs);
}

Client* ClientFactoryImpl::getClient( const char* _key )
{
	std::string key(_key);
	//
	ScopedLock csLock(cs);

	clientMapT::iterator it = clientMap.find(key);
	if(it==clientMap.end())
		return NULL;

	Client* pClient = it->second;

	pClient->pImpl->getRefCount()++;
	return pClient;
}

void ClientFactoryImpl::returnClient( const char* _key )
{
	std::string key(_key);
	//
	::EnterCriticalSection(&cs);
	//
	clientMapT::iterator it = clientMap.find(key);
	Client* pClient = it->second;
	//
	pClient->pImpl->getRefCount()--;
	if (pClient->pImpl->getRefCount()==0 && pClient->pImpl->isDisconnected())
	{
		wcout << L"Disposing Client" << std::endl;
		clientMap.erase(it);
		::LeaveCriticalSection(&cs);
		//
		pFacade->onBeforeDisposeClient(pClient);

		pServerImpl->getBroadcastManager()->pImpl->removeClient(_key);
		pServerImpl->getDispatcher()->NotifyObserversClientOut(_key);


		//Statistics :
		pServerImpl->getStats()->addToCumul(ServerStats::VisitorsHitsOut, 1);
		pServerImpl->getStats()->addToCumul(ServerStats::VisitorsOnline, -1);
		pServerImpl->getStats()->addToDuration(ServerStats::VisitorsDuration, pClient->pImpl->getVisitDuration());


		//delete
		pFacade->disposeClient(pClient);
	}
	else
		LeaveCriticalSection(&cs);
}

void ClientFactoryImpl::setServerImpl( ServerImpl* pServerImpl )
{
	this->pServerImpl = pServerImpl;
}

Server* ClientFactoryImpl::getServer()
{
	return pServerImpl->getFacade();
}


}

