/********************************************************************
	File :			ClientImpl.cpp
	Creation date :	2010/6/27
		
	License :			Copyright 2010 Ahmed Charfeddine, http://www.pushframework.com

				   Licensed under the Apache License, Version 2.0 (the "License");
				   you may not use this file except in compliance with the License.
				   You may obtain a copy of the License at
				
					   http://www.apache.org/licenses/LICENSE-2.0
				
				   Unless required by applicable law or agreed to in writing, software
				   distributed under the License is distributed on an "AS IS" BASIS,
				   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
				   See the License for the specific language governing permissions and
				   limitations under the License.
	
	
*********************************************************************/
#include "StdAfx.h"
#include "ClientImpl.h"

#include "ServerImpl.h"
#include "..\include\OutgoingPacket.h"
#include "..\include\Protocol.h"
#include "ChannelFactory.h"

namespace PushFramework{


ClientImpl::ClientImpl()
{
}

ClientImpl::~ClientImpl(void)
{
}


ULONG& ClientImpl::getRefCount()
{
	return m_RefCount;
}

unsigned int ClientImpl::getChannel()
{
	return m_channelKey;
}

void ClientImpl::setChannel( unsigned int m_channelKey )
{
	this->m_channelKey = m_channelKey;
}

void ClientImpl::setServerImpl( ServerImpl* pServer )
{
	this->pServer = pServer;
}

bool ClientImpl::isDisconnected()
{
	return bDisconnected;
}

bool ClientImpl::PushPacket( OutgoingPacket* pPacket )
{
	CChannel* pChannel = pServer->getChannelFactory()->getObject(m_channelKey);
	if (pChannel)
	{
		bool bSent = pChannel->PushPacket(pPacket);
		pServer->getChannelFactory()->disposeObject(m_channelKey);
		return bSent;			
	}
	else
		return false;
}

void ClientImpl::disconnect( bool waitForPendingPackets )
{
	CChannel* pChannel = pServer->getChannelFactory()->getObject(m_channelKey);
	if (pChannel)
	{
		pChannel->Close(waitForPendingPackets);
		pServer->getChannelFactory()->disposeObject(m_channelKey);
	}
	bDisconnected = true;
}

double ClientImpl::getVisitDuration()
{
	COleDateTimeSpan dtSpan = COleDateTime::GetCurrentTime() - dtConnectTime;
	return dtSpan.GetTotalSeconds();
}

void ClientImpl::init()
{
	m_RefCount = 0;
	bDisconnected = false;
	dtConnectTime = COleDateTime::GetCurrentTime();
}
}

