/********************************************************************
	File :			Dispatcher.h
	Creation date :	2010/6/27
		
	License :			Copyright 2010 Ahmed Charfeddine, http://www.pushframework.com

				   Licensed under the Apache License, Version 2.0 (the "License");
				   you may not use this file except in compliance with the License.
				   You may obtain a copy of the License at
				
					   http://www.apache.org/licenses/LICENSE-2.0
				
				   Unless required by applicable law or agreed to in writing, software
				   distributed under the License is distributed on an "AS IS" BASIS,
				   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
				   See the License for the specific language governing permissions and
				   limitations under the License.
	
	
*********************************************************************/
#ifndef Dispatcher__INCLUDED
#define Dispatcher__INCLUDED

#pragma once

#include "BroadcastChannel.h"


namespace PushFramework{

class Service;
class ServerImpl;
class CChannel;
class IncomingPacket;
class MonitorsBroadcastManager;

class Dispatcher
{
public:
	Dispatcher(ServerImpl* pServerImpl);
	~Dispatcher(void);
	void OnWriteComplete(CChannel* pChannel,DWORD dwIoSize);
	void OnReceiveComplete(CChannel* pChannel,DWORD dwIoSize);
	void OnInitializeReady(CChannel* pChannel);
	void OnStartGC();
	void OnStartProfiling();
	void registerService(unsigned int uCommmand, Service* pService, std::string serviceName);
private:
	ServerImpl* pServerImpl;
public:
	std::string getServiceNames();
	void setCurrentService(std::string serviceName);
	void UnsetCurrentService();
	bool getCurrentService(std::string& serviceName);
private:
	typedef struct ServiceInfo 
	{
		Service* pService;
		std::string serviceName;
	}ServiceInfo;
	typedef std::map<unsigned int, ServiceInfo*> serviceMapT;
	typedef std::map<DWORD, std::string> workerServiceMapT;

	//List of services :
	serviceMapT serviceMap;

	//Reference to dispatched services :
	workerServiceMapT workerServiceMap;
	CRITICAL_SECTION csSrvMap;
	LARGE_INTEGER	m_QPFrequency;
private:
	MonitorsBroadcastManager* pMonitorsBroadcastManager;

public:


	void ProcessClientPendingPackets(CChannel* pChannel);
	void NotifyObserversClientIN(const char* key, std::string peerIP, unsigned int peerPort);
	void NotifyObserversClientOut(const char* key);
private:
	void dispatchRequest(unsigned int uCommand,const char* uClient,IncomingPacket& packet,unsigned int serviceBytes);
	void ProcessFirstPacket(CChannel* pChannel,unsigned int uCommand, IncomingPacket& packet,unsigned int serviceBytes);
	void HandleMonitorRequest(CChannel* pChannel, IncomingPacket& packet);
	void ProcessMonitorFirstPacket(CChannel* pChannel, IncomingPacket& packet);

};

}

#endif // Dispatcher__INCLUDED
