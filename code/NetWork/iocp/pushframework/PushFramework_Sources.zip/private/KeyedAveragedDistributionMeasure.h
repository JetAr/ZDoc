#pragma once

#include "measure.h"


namespace PushFramework{

	class KeyedAveragedDistributionMeasureArgs : public MeasureArgs
	{
	public:
		std::string serviceName;
		std::string key;
		double value;
	};

	class KeyedAveragedDistributionMeasure :
		public Measure
	{
		typedef std::map<std::string, double> innerObservationMapT;
		typedef std::map<std::string, innerObservationMapT*> mappedValuesT;

	public:
		KeyedAveragedDistributionMeasure(std::string name);
		~KeyedAveragedDistributionMeasure(void);

		virtual void addObservation( MeasureArgs& args );
		std::string collectAndReset( std::string timeStamp );
	private:
		void addInnerObservation(innerObservationMapT* pSegment, std::string key, double value);
		double getMean(innerObservationMapT& segment);
		double getDispersion(innerObservationMapT& segment, double mean );
	private:
		mappedValuesT mappedValues;
		//
	};

}