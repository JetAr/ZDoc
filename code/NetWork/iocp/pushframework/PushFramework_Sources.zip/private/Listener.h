/********************************************************************
	File :			Listener.h
	Creation date :	2010/6/27
		
	License :			Copyright 2010 Ahmed Charfeddine, http://www.pushframework.com

				   Licensed under the Apache License, Version 2.0 (the "License");
				   you may not use this file except in compliance with the License.
				   You may obtain a copy of the License at
				
					   http://www.apache.org/licenses/LICENSE-2.0
				
				   Unless required by applicable law or agreed to in writing, software
				   distributed under the License is distributed on an "AS IS" BASIS,
				   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
				   See the License for the specific language governing permissions and
				   limitations under the License.
	
	
*********************************************************************/
#ifndef Listener__INCLUDED
#define Listener__INCLUDED

#pragma once

#include "..\include\ListenerOptions.h"

namespace PushFramework{


class Listener
{
public:
	Listener();
	~Listener(void);
	void setListeningPort(unsigned int uPort);
	bool startListening();
	void stopListening();
	ListenerOptions& getOptions();
private:
	unsigned int uPort;
	SOCKET					hSocket; //socket handle.
	WSAEVENT				hSocketEvent;//used for WSAEventSelect.
	HANDLE					hThread;//Handle to the listening thread.
	static unsigned __stdcall threadProc(LPVOID lpVoid);
	void doListen();
	bool acceptConnectionRequest();
	HANDLE	hKillEvent;//kill event.
protected:
	ListenerOptions options;
	virtual bool handleAcceptedSocket(SOCKET clientSocket, SOCKADDR_IN address) = 0;
private:
	
};

}

#endif // Listener__INCLUDED
