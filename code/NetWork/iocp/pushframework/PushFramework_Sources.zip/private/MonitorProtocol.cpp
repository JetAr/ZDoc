/********************************************************************
	File :			MonitorProtocol.cpp
	Creation date :	2010/6/27
		
	License :			Copyright 2010 Ahmed Charfeddine, http://www.pushframework.com

				   Licensed under the Apache License, Version 2.0 (the "License");
				   you may not use this file except in compliance with the License.
				   You may obtain a copy of the License at
				
					   http://www.apache.org/licenses/LICENSE-2.0
				
				   Unless required by applicable law or agreed to in writing, software
				   distributed under the License is distributed on an "AS IS" BASIS,
				   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
				   See the License for the specific language governing permissions and
				   limitations under the License.
	
	
*********************************************************************/
#include "StdAfx.h"
#include "MonitorProtocol.h"

#include "MonitorRequestPacket.h"
#include "MonitorResponsePacket.h"

namespace PushFramework{


MonitorProtocol::MonitorProtocol(void)
{
}

MonitorProtocol::~MonitorProtocol(void)
{
}

void MonitorProtocol::disposeOutgoingPacket( OutgoingPacket* pPacket )
{
	delete pPacket;
}

void MonitorProtocol::disposeIncomingPacket( IncomingPacket* pPacket )
{
	delete pPacket;
}

int MonitorProtocol::encodeOutgoingPacket( OutgoingPacket& packet )
{
	MonitorResponsePacket& response = (MonitorResponsePacket&) packet;

	return response.Encode() ? Success : eEncodingFailure;
}

int MonitorProtocol::frameOutgoingPacket( OutgoingPacket& packet, DataBuffer& buffer, unsigned int& nWrittenBytes )
{
	MonitorResponsePacket& response = (MonitorResponsePacket&) packet;
	
	nWrittenBytes = response.getBufferLen() + 1;
	if (nWrittenBytes > buffer.getRemainingSize())
		return eInsufficientBuffer;

	buffer.Append(response.getBuffer(), response.getBufferLen());

	char endChar = 0;

	buffer.Append(&endChar, 1);

	return Success;
}

/*
int MonitorProtocol::serializeOutgoingPacket( OutgoingPacket* pPacket, char* pBuffer, unsigned int uBufferSize, unsigned int& uWrittenBytes )
{
	MonitorResponsePacket* pResponse = (MonitorResponsePacket*) pPacket;
	if (!pResponse->Encode())
	{
		return eDecodingFailure;
	}

	unsigned int uBytesToSerialize = pResponse->getBufferLen() + 1;


	if (uBytesToSerialize > uBufferSize)
	{
		return eInsufficientBuffer;
	}

	CopyMemory(pBuffer, pResponse->getBuffer(), pResponse->getBufferLen());

	pBuffer[pResponse->getBufferLen()] = 0;


	uWrittenBytes = pResponse->getBufferLen()+1;

	return Success;
}*/


int MonitorProtocol::tryDeframeIncomingPacket( DataBuffer& buffer, IncomingPacket*& pPacket, int& serviceId, unsigned int& nExtractedBytes )
{
	serviceId = 1;

	for (int offset  = 0; offset < buffer.GetDataSize(); offset++)
	{
		char ch = buffer.getAt(offset);
		if (ch=='\0')
		{
			nExtractedBytes = offset +1;
			//It is ok
			MonitorRequestPacket* pRequest = new MonitorRequestPacket();
			if (!pRequest->Decode(buffer.GetBuffer(), offset))
			{
				delete pRequest;
				return eDecodingFailure;
			}
			else
			{
				pPacket = (IncomingPacket*) pRequest;
				return Success;
			}
		}
	}
	return eIncompletePacket;
}
/*


int MonitorProtocol::tryDeframeIncomingPacket( char* pBuffer, unsigned int uBufferSize, unsigned int& uCommandID, IncomingPacket*& lpMessage, unsigned int& uExtractedBytes )
{
	uCommandID = 1;
	char* pString = pBuffer;
	for (unsigned int i = 0;i<uBufferSize;i++)
	{
		char& ch = pString[i];
		if (ch=='\0')
		{
			//It is ok
			MonitorRequestPacket* pRequest = new MonitorRequestPacket();
			if (!pRequest->Decode(pBuffer, i))
			{
				delete pRequest;
				return Protocol::eDecodingFailure;
			}
			lpMessage = (IncomingPacket*) pRequest;
			uExtractedBytes = i+1;
			return Protocol::Success;
		}
	}
	return Protocol::eIncompletePacket;
}*/


int MonitorProtocol::decodeIncomingPacket( IncomingPacket* pPacket, int& serviceId )
{
	return Protocol::Success;
}





}

