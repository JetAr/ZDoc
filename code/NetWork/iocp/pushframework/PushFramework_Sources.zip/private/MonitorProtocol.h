/********************************************************************
	File :			MonitorProtocol.h
	Creation date :	2010/6/27
		
	License :			Copyright 2010 Ahmed Charfeddine, http://www.pushframework.com

				   Licensed under the Apache License, Version 2.0 (the "License");
				   you may not use this file except in compliance with the License.
				   You may obtain a copy of the License at
				
					   http://www.apache.org/licenses/LICENSE-2.0
				
				   Unless required by applicable law or agreed to in writing, software
				   distributed under the License is distributed on an "AS IS" BASIS,
				   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
				   See the License for the specific language governing permissions and
				   limitations under the License.
	
	
*********************************************************************/
#ifndef MonitorProtocol__INCLUDED
#define MonitorProtocol__INCLUDED

#pragma once

#include "..\include\Protocol.h"

namespace PushFramework{


class MonitorProtocol :
	public Protocol
{
public:
	MonitorProtocol(void);
	~MonitorProtocol(void);

/*
	virtual int serializeOutgoingPacket(OutgoingPacket* pPacket, char* pBuffer, unsigned int uBufferSize, unsigned int& uWrittenBytes);
	virtual int tryDeframeIncomingPacket(char* pBuffer, unsigned int uBufferSize, unsigned int& uCommandID, IncomingPacket*& lpMessage, unsigned int& uExtractedBytes);
*/
	
	
	virtual void disposeOutgoingPacket(OutgoingPacket* pPacket);
	virtual void disposeIncomingPacket(IncomingPacket* pPacket);


	//////////////////////////////////////////////////////////////////////////
	virtual int encodeOutgoingPacket(OutgoingPacket& packet);
	virtual int frameOutgoingPacket(OutgoingPacket& packet, DataBuffer& buffer, unsigned int& nWrittenBytes);
	//////////////////
	virtual int tryDeframeIncomingPacket(DataBuffer& buffer, IncomingPacket*& pPacket, int& serviceId, unsigned int& nExtractedBytes);
	virtual int decodeIncomingPacket(IncomingPacket* pPacket, int& serviceId);


};

}

#endif // MonitorProtocol__INCLUDED
