#include "StdAfx.h"
#include "MonitorsBroadcastManager.h"

#include "ChannelFactory.h"

namespace PushFramework{

MonitorsBroadcastManager::MonitorsBroadcastManager( ChannelFactory* pChannelFactory )
{
	this->pChannelFactory = pChannelFactory;

	createChannel("stats", 100, false, 10, 10);
	createChannel("clientsIn", 1000, false, 5, 5);
	createChannel("clientsOut", 50, false, 5, 5);
}

MonitorsBroadcastManager::~MonitorsBroadcastManager( void )
{
	//
}

void MonitorsBroadcastManager::ActivateSubscribers( std::string channelName )
{
	pChannelFactory->ProcessPendingObserversPackets();
}

void MonitorsBroadcastManager::PreEncodeOutgoingPacket( OutgoingPacket* pPacket )
{
	//Nothing to do, packet is already encoded.
}

void MonitorsBroadcastManager::DeleteOutgoingPacket( OutgoingPacket* pPacket )
{
	delete pPacket;
}

}