#pragma once

#include "..\include\PushFramework.h"

#include "BroadcastManagerImplBase.h"
namespace PushFramework{

class ChannelFactory;

class MonitorsBroadcastManager : public BroadcastManagerImplBase
{
public:
	MonitorsBroadcastManager(ChannelFactory* pChannelFactory);
	~MonitorsBroadcastManager(void);

protected:
	virtual void PreEncodeOutgoingPacket(OutgoingPacket* pPacket);
	virtual void DeleteOutgoingPacket(OutgoingPacket* pPacket);
	virtual void ActivateSubscribers(std::string channelName);

private:
	ChannelFactory* pChannelFactory;
};

}
