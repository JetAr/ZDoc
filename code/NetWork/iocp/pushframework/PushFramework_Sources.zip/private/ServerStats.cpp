/********************************************************************
	File :			ServerStats.cpp
	Creation date :	2010/6/27
		
	License :			Copyright 2010 Ahmed Charfeddine, http://www.pushframework.com

				   Licensed under the Apache License, Version 2.0 (the "License");
				   you may not use this file except in compliance with the License.
				   You may obtain a copy of the License at
				
					   http://www.apache.org/licenses/LICENSE-2.0
				
				   Unless required by applicable law or agreed to in writing, software
				   distributed under the License is distributed on an "AS IS" BASIS,
				   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
				   See the License for the specific language governing permissions and
				   limitations under the License.
	
	
*********************************************************************/
#include "StdAfx.h"
#include "ServerStats.h"

#include "Measure.h"
#include "DistributionMeasure.h"
#include "CumulativeMeasure.h"
#include "DurationMeasure.h"
#include "KeyedAveragedMeasure.h"
#include "KeyedAveragedDistributionMeasure.h"



#include "ServerImpl.h"
#include "..\include\Protocol.h"
#include "MonitorProtocol.h"
#include "MonitorResponsePacket.h"
#include "Dispatcher.h"
#include "BroadcastManagerImpl.h"



#include "ScopedLock.h"


namespace PushFramework{


ServerStats::ServerStats(ServerImpl* pServerImpl)
{
	packetCounter = 0;
	::InitializeCriticalSection(&cs);
	init();
	this->pServerImpl = pServerImpl;
}

ServerStats::~ServerStats(void)
{
	::DeleteCriticalSection(&cs);
}

void ServerStats::init()
{
	//Create measures.

	//Visitors :
	measuresMap[VisitorsOnline] = new CumulMeasure("online", true);

	measuresMap[VisitorsHitsIn] = new CumulMeasure("hitsIn");
	measuresMap[VisitorsHitsOut] = new CumulMeasure("hitsOut");
	measuresMap[VisitorsSYNs] = new CumulMeasure("syn");

	measuresMap[VisitorsDuration] = new DurationMeasure("duration");

	measuresMap[VisitorsBounce] = new CumulMeasure("bounce");

	//Bandwidth :
	measuresMap[BandwidthInbound] = new CumulMeasure("inbound");
	measuresMap[BandwidthOutbound] = new CumulMeasure("outbound");
	measuresMap[BandwidthRejection] = new CumulMeasure("rejection");
	measuresMap[BandwidthOutstanding] = new CumulMeasure("outstanding");

	measuresMap[BandwidthInboundVolPerRequest] = new DistributionMeasure("inboundvol");
	measuresMap[BandwidthOutboundVolPerRequest] = new DistributionMeasure("outboundvol");

	measuresMap[BandwidthInboundPerConnection] = new KeyedAveragedMeasure("inbound");
	measuresMap[BandwidthOutboundPerConnection] = new KeyedAveragedMeasure("outbound");

	//Performance :
	measuresMap[PerformanceRequestVolPerRequest] = new DistributionMeasure("requestvolume");
	measuresMap[PerformanceProcessingTime] = new DurationMeasure("processing");
	measuresMap[PerformanceProcessingTimePerService] = new DistributionMeasure("processingbyreq");
	
	//Qos Broadcast :
	measuresMap[QoSFillRatePerChannel] = new DistributionMeasure("fillrate");
	measuresMap[QoSSendRatePerChannel] = new DistributionMeasure("sendrate");
	measuresMap[QoSAvgSendRatePerChannel] = new KeyedAveragedDistributionMeasure("avgsendrate");

}

void ServerStats::addToCumul( unsigned int measureId, double value )
{
	if (pServerImpl->getProfilingStatus()==false)
		return;

	ScopedLock lock(cs);

	CumulMeasureArgs args;
	args.dwValue = value;

	measuresMap[measureId]->addObservation(args);
}

void ServerStats::addToDuration( unsigned int measureId, double value )
{
	if (pServerImpl->getProfilingStatus()==false)
		return;

	ScopedLock lock(cs);

	DurationMeasureArgs args;
	args.duration = value;

	measuresMap[measureId]->addObservation(args);
}

void ServerStats::addToDistribution( unsigned int measureId, std::string serviceName, double value )
{
	if (pServerImpl->getProfilingStatus()==false)
		return;

	ScopedLock lock(cs);

	DistributionMeasureArgs args;
	args.serviceName = serviceName;
	args.value = value;

	measuresMap[measureId]->addObservation(args);
}

OutgoingPacket* ServerStats::getPerformancePacket()
{

	ScopedLock lock(cs);

	packetCounter++;

	
	std::string timestamp  = Utilities::getCurrentTime();
	
	// = "22:00::23";

	std::stringstream ss;

	ss << std::noskipws;

	//Write header :
	ss << "<root type=\"obs\">";
	ss << "<id value=\"" << packetCounter << "\"/>";
	ss << "<timestamp value=\"" << timestamp << "\"/>";

	//Visitors :
	ss << "<visitors>";
	ss << measuresMap[VisitorsOnline]->collectAndReset(timestamp);
	ss << "<hits>";
	ss << measuresMap[VisitorsHitsIn]->collectAndReset(timestamp);
	ss << measuresMap[VisitorsHitsOut]->collectAndReset(timestamp);
	ss << measuresMap[VisitorsSYNs]->collectAndReset(timestamp);
	ss << "</hits>";
	ss << measuresMap[VisitorsDuration]->collectAndReset(timestamp);
	//ss << "<visitorlist><visitor><time value=\"23:00\"/><ip value=\"192.168.1.1\"/><port value=\"1209\"/></visitor></visitorlist>";
	ss << measuresMap[VisitorsBounce]->collectAndReset(timestamp);
	ss << "</visitors>";

	//Bandwidth :
	ss << "<bandwidth>";
	ss << "<total>";
	ss << measuresMap[BandwidthInbound]->collectAndReset(timestamp);
	ss << measuresMap[BandwidthOutbound]->collectAndReset(timestamp);
	ss << measuresMap[BandwidthRejection]->collectAndReset(timestamp);
	ss << measuresMap[BandwidthOutstanding]->collectAndReset(timestamp);
	ss << "</total>";
	ss << measuresMap[BandwidthInboundVolPerRequest]->collectAndReset(timestamp);
	ss << measuresMap[BandwidthOutboundVolPerRequest]->collectAndReset(timestamp);
	ss << "<perconnection>";
	ss << measuresMap[BandwidthInboundPerConnection]->collectAndReset(timestamp);
	ss << measuresMap[BandwidthOutboundPerConnection]->collectAndReset(timestamp);
	ss << "</perconnection>";
	ss << "</bandwidth>";

	//Performance :
	ss << "<performance>";
	ss << measuresMap[PerformanceRequestVolPerRequest]->collectAndReset(timestamp);
	ss << measuresMap[PerformanceProcessingTime]->collectAndReset(timestamp);
	ss << measuresMap[PerformanceProcessingTimePerService]->collectAndReset(timestamp);
	ss << "</performance>";


	//QoS Broadcast :
	ss << "<qos>";
	ss << measuresMap[QoSFillRatePerChannel]->collectAndReset(timestamp);
	ss << measuresMap[QoSSendRatePerChannel]->collectAndReset(timestamp);
	ss << measuresMap[QoSAvgSendRatePerChannel]->collectAndReset(timestamp);
	ss << "</qos>";

	
	ss << "</root>";

	std::string data = ss.str();

	return new MonitorResponsePacket(data);
}

void ServerStats::addToKeyedDuration(unsigned int measureId, unsigned int key, double value )
{
	if (pServerImpl->getProfilingStatus()==false)
		return;

	ScopedLock lock(cs);
	//
	MKAveragedMeasureArgs args;
	args.dwValue = value;
	args.key = key;

	measuresMap[measureId]->addObservation(args);
}

void ServerStats::addToKeyedDistributionDuration( unsigned int measureId, std::string segmentName,std::string key, double value )
{
	if (pServerImpl->getProfilingStatus()==false)
		return;

	ScopedLock lock(cs);
	//
	KeyedAveragedDistributionMeasureArgs args;
	args.key = key;
	args.serviceName = segmentName;
	args.value = value;

	measuresMap[measureId]->addObservation(args);
}

OutgoingPacket* ServerStats::getInitializationPacket()
{
	ScopedLock lock(cs);

	std::stringstream ss;
	ss << std::noskipws;
	
	//Write header :
	ss << "<root type=\"init\">";

	ss << "<sampling value=\"" << pServerImpl->getSamplingRate() << "\"/>";
	ss << "<requests>";

	Dispatcher* pDispatcher = pServerImpl->getDispatcher();
	ss << pDispatcher->getServiceNames();

	ss << "</requests>";


	
	ss << "<channels>";

	BroadcastManagerImpl* pBroadcastMgrImpl = pServerImpl->getBroadcastManagerImpl();
	ss << pBroadcastMgrImpl->getChannelsNames();

	ss << "</channels>";


	ss << "</root>";


	std::string data = ss.str();
	return new MonitorResponsePacket(data);
}



}
