#include "StdAfx.h"
#include "MyQoSClient.h"

CMyQoSClient::CMyQoSClient(void)
{
	registerHandler(1, this); // incoming packets will be redirected back to this class via ::handleResponse method.
	setProtocol(new QoSExampleProtocol);
}

CMyQoSClient::~CMyQoSClient(void)
{
}

void CMyQoSClient::onConnected( bool bResult )
{
	std::cout << (bResult ? "connection success" : "connection failure") << std::endl;

	if (bResult)
	{
		CQoSPacket packet;
		TCPSocket::sendRequest(&packet);
	}
}

void CMyQoSClient::onConnectionClosed( bool bPeerClose )
{
	std::cout << (bPeerClose ? "connection closed by peer" : "connection closed") << std::endl;
}

void CMyQoSClient::handleResponse( PushFramework::IncomingPacket& packet )
{
	CQoSPacket& response = (CQoSPacket&) packet;

	//std::cout << "new response " << response.getPacketId() << std::endl;
	//
	statsMapT::iterator it = statsMap.find(response.getChannelSourceId());
	if (it == statsMap.end()){
		ChannelPacketsInfo* pInfo = new ChannelPacketsInfo;
		pInfo->lastReceivedId = response.getPacketId();
		pInfo->uPacketsCount = 1;
		pInfo->uMissedCount = 0;
		pInfo->nDuplicates = 0;

		statsMap[response.getChannelSourceId()] = pInfo;
	}
	else{
		ChannelPacketsInfo* pInfo = it->second;
		//
		pInfo->uPacketsCount++;

		if (pInfo->uPacketsCount == UINT_MAX)
		{
			exit(-1);
		}
	
		/*
			int nMissed = response.getPacketId() - pInfo->lastReceivedId -1;
					if (nMissed == -1)
						pInfo->nDuplicates++;
					else if (nMissed < -1)
					{
						cout << "nMissed < -1 FATAL " << endl;
						exit(-1);
					}
					else
						pInfo->uMissedCount+= nMissed;*/
			

		pInfo->lastReceivedId = response.getPacketId();
	}
}
