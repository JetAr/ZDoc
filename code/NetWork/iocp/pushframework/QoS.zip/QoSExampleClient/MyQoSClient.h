#pragma once



typedef struct ChannelPacketsInfo
{
	unsigned int uPacketsCount;
	unsigned int uMissedCount;
	unsigned int lastReceivedId;
	unsigned int nDuplicates;
};
typedef std::map<unsigned int, ChannelPacketsInfo*> statsMapT;

class CMyQoSClient : public TCPSocket, public ResponseHandler
{
public:
	CMyQoSClient(void);
	~CMyQoSClient(void);

protected:
	virtual void onConnected(bool bResult);
	virtual void onConnectionClosed(bool bPeerClose);

	virtual void handleResponse(PushFramework::IncomingPacket& packet);
	statsMapT statsMap;
	
public:
	statsMapT& getStatsMap() { return statsMap; }
};



