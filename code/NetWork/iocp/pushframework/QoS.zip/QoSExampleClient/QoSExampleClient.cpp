// QoSExampleClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "MyQoSClient.h"
char hostAddress[] = "127.0.0.1";
unsigned int uPort = 2010;

#include "StopWatch.h"

int _tmain(int argc, _TCHAR* argv[])
{
	TCPSocket::initializeWinsock();


	CMyQoSClient client;

	cout << "Connecting " << std::endl;

	if (!client.connect(hostAddress, uPort))
	{
		cout << "Unable to connect " << std::endl;
	}
	cout << "Put Q or q to stop" << std::endl;
	int ch;


	StopWatch watch;

	do 
	{
		ch = _getch();
		ch = toupper(ch);

	} while (ch !='Q');

	double dTimeDuration = watch.GetElapsedTime(true);

	client.disconnect(false);


	//Show statistics :


	//Calculate total packets received : 
	double nTotal = 0;
	statsMapT::iterator it;
	statsMapT& statsMap = client.getStatsMap();
	for (it = statsMap.begin() ;it!=statsMap.end();it++)
	{
		nTotal += it->second->uPacketsCount;
	}
	//Deduce the download rate :
	double packetAvgSize = 8008;
	int nPacketsRate = (int) (((double) nTotal) / dTimeDuration) ;
	int nMBytesPerSeconds = (int) (packetAvgSize * (((double) nTotal) / dTimeDuration) /( 1024*1024));




	cout << "Total received : " << nTotal << "\tDownload rate :" << nMBytesPerSeconds << " MBps\tPackets rate :" << nPacketsRate << " packet per sec" << std::endl;





	for (it = statsMap.begin() ;it!=statsMap.end();it++)
	{
		ChannelPacketsInfo* pInfo = it->second;

		int nPercent = pInfo->uPacketsCount* 100 / nTotal;
		int nRejection = (int) ((double)(pInfo->uMissedCount)* 100 / (double)(pInfo->uMissedCount + pInfo->uPacketsCount));

		cout << "#" << it->first << " : " << pInfo->uPacketsCount << " packets received\t" << nPercent << " % of total\tRejection rate :" << nRejection << " %Duplicates :" << pInfo->nDuplicates << std::endl;
	}

	cout << std::endl;
	cout << "Press a key to quit" << std::endl;

	ch = _getch();

	return 0;
}

