#include "stdafx.h"

#include "StopWatch.h"

StopWatch::StopWatch()
{
	ZeroMemory(&m_QPFrequency, sizeof(m_QPFrequency));
	QueryPerformanceFrequency(&m_QPFrequency);

	ZeroMemory(&m_StartCounter,sizeof(m_StartCounter));
	QueryPerformanceCounter (&m_StartCounter);

	reset();

}

void StopWatch::reset()
{
	ZeroMemory(&m_LastCounter,sizeof(m_LastCounter));
	QueryPerformanceCounter (&m_LastCounter);
}

double StopWatch::GetElapsedTime(bool bStart /*= true*/)
{
	LARGE_INTEGER	curCounter;
	ZeroMemory(&curCounter, sizeof(curCounter));
	QueryPerformanceCounter (&curCounter);
	//
	__int64			m_ElapsedTime=(curCounter.QuadPart  - (bStart ? m_StartCounter.QuadPart :  m_LastCounter.QuadPart));

	if(!bStart)
		reset();

	return (static_cast<double>(m_ElapsedTime) / static_cast<double>(m_QPFrequency.QuadPart));
}