#pragma once

class StopWatch
{
public:

	StopWatch();

	void reset();
	~StopWatch(void)
	{
	}

	double GetElapsedTime(bool bStart = true);
private:
	LARGE_INTEGER	m_QPFrequency;
	LARGE_INTEGER	m_StartCounter;
	LARGE_INTEGER	m_LastCounter;
};