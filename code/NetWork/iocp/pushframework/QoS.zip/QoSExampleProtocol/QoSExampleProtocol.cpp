// QoSExampleProtocol.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "QoSExampleProtocol.h"


#define SignatureStart 16018
#define SignatureEnd 16108



void QoSExampleProtocol::disposeOutgoingPacket( PushFramework::OutgoingPacket* pPacket )
{
	delete pPacket;
}

void QoSExampleProtocol::disposeIncomingPacket( PushFramework::IncomingPacket* pPacket )
{
	delete pPacket;
}


int QoSExampleProtocol::encodeOutgoingPacket( PushFramework::OutgoingPacket& packet )
{
	CQoSPacket& qoSPacket = (CQoSPacket&) packet;
	if(!qoSPacket.Encode())
		return PushFramework::Protocol::eEncodingFailure;
	else
		return PushFramework::Protocol::Success;
}


int QoSExampleProtocol::frameOutgoingPacket( PushFramework::OutgoingPacket& packet, PushFramework::DataBuffer& buffer, unsigned int& nWrittenBytes )
{
	//Write the header : eSignature plus the size of our packet :

	//First compute the required size and verify that data will fit into the target buffer :

	CQoSPacket& qoSPacket = (CQoSPacket&) packet;

	nWrittenBytes = 8 + qoSPacket.getDataSize();
	
	if (nWrittenBytes > buffer.getRemainingSize())
		return PushFramework::Protocol::eInsufficientBuffer;

	unsigned int sStart = SignatureStart;
	unsigned int packetLen = nWrittenBytes;
	unsigned int commandID = 1;
	unsigned int sEnd = SignatureEnd;

	buffer.Append((char*)&sStart, 2);
	buffer.Append((char*)&packetLen, 2);
	buffer.Append((char*)&commandID, 2);

	buffer.Append(qoSPacket.getData(), qoSPacket.getDataSize());
	
	buffer.Append((char*)&sEnd, 2);

	return PushFramework::Protocol::Success;

}

int QoSExampleProtocol::tryDeframeIncomingPacket( PushFramework::DataBuffer& buffer, PushFramework::IncomingPacket*& pPacket, int& serviceId, unsigned int& nExtractedBytes )
{
	if(buffer.GetDataSize() < 8)
		return PushFramework::Protocol::eIncompletePacket;

	unsigned int sStart = 0;
	unsigned int packetLen = 0;
	serviceId = 0;
	unsigned int sEnd = 0;

	char* pBuffer = buffer.GetBuffer();
	//Read header :

	for (int i=0;i<2;i++)
	{
		*((BYTE*)(&sStart)+i)=pBuffer[i];
		*((BYTE*)(&packetLen)+i)=pBuffer[i+2];
		*((BYTE*)(&serviceId)+i)=pBuffer[i+4];
	}

	if (sStart!=SignatureStart)
		return PushFramework::Protocol::eCorruptPacket;

	if (packetLen > buffer.GetDataSize())
		return PushFramework::Protocol::eIncompletePacket;

	for (int i=0;i<2;i++)
		*((BYTE*)(&sEnd)+i)=pBuffer[packetLen-2+i];

	if(sEnd!=SignatureEnd)
		return PushFramework::Protocol::eCorruptPacket;

	//Ended header and footer verification. Construct the incoming packet :
	nExtractedBytes = packetLen;


	char* pData = pBuffer + 6;
	unsigned int dataSize = packetLen - 8;

	CQoSPacket* pQoSPacket = new CQoSPacket();

	if(!pQoSPacket->Decode(pData, dataSize))
	{
		disposeIncomingPacket(pQoSPacket);
		return PushFramework::Protocol::eDecodingFailure;
	}

	pPacket = pQoSPacket;
	serviceId = 1;
	return PushFramework::Protocol::Success;
}


int QoSExampleProtocol::decodeIncomingPacket( PushFramework::IncomingPacket* pPacket, int& serviceId )
{
	return PushFramework::Protocol::Success;
}


/*
int QoSExampleProtocol::serializeOutgoingPacket( PushFramework::OutgoingPacket* pPacket, char* pBuffer, unsigned int uBufferSize, unsigned int& uWrittenBytes )
{
	CQoSPacket* pQoSPacket = (CQoSPacket*) pPacket;
	if(!pPacket->Encode())
		return PushFramework::Protocol::eEncodingFailure;

	if ( (pQoSPacket->getDataSize() + 8) > uBufferSize)
		return PushFramework::Protocol::eInsufficientBuffer;



	unsigned int sStart = SignatureStart;
	unsigned int packetLen = pQoSPacket->getDataSize() + 8;
	unsigned int commandID = 1;
	unsigned int sEnd = SignatureEnd;

	for (int i=0;i<2;i++)
	{
		pBuffer[i] = *((BYTE*)(&sStart)+i);
		pBuffer[i+2] = *((BYTE*)(&packetLen)+i);
		pBuffer[i+4] = *((BYTE*)(&commandID)+i);
	}

	CopyMemory(pBuffer + 6, pQoSPacket->getData(), pQoSPacket->getDataSize());

	for (int i=0;i<2;i++)
		pBuffer[packetLen-2+i] = *((BYTE*)(&sEnd)+i);

	uWrittenBytes = 8 + pQoSPacket->getDataSize();

	return PushFramework::Protocol::Success;
}



int QoSExampleProtocol::tryDeframeIncomingPacket( char* pBuffer, unsigned int uBufferSize, unsigned int& serviceId, PushFramework::IncomingPacket*& lpMessage, unsigned int& uExtractedBytes )
{
	if(uBufferSize < 8)
		return PushFramework::Protocol::eIncompletePacket;

	unsigned int sStart = 0;
	unsigned int packetLen = 0;
	serviceId = 0;
	unsigned int sEnd = 0;

	for (int i=0;i<2;i++)
	{
		*((BYTE*)(&sStart)+i)=pBuffer[i];
		*((BYTE*)(&packetLen)+i)=pBuffer[i+2];
		*((BYTE*)(&serviceId)+i)=pBuffer[i+4];
	}

	if (sStart!=SignatureStart)
		return PushFramework::Protocol::eCorruptPacket;

	if (packetLen > uBufferSize)
		return PushFramework::Protocol::eIncompletePacket;

	for (int i=0;i<2;i++)
		*((BYTE*)(&sEnd)+i)=pBuffer[packetLen-2+i];

	if(sEnd!=SignatureEnd)
		return PushFramework::Protocol::eCorruptPacket;

	char* pData = pBuffer + 6;
	unsigned int dataSize = packetLen - 8;

	CQoSPacket* pQoSPacket = new CQoSPacket();

	if(!pQoSPacket->Decode(pData, dataSize))
	{
		disposeIncomingPacket(pQoSPacket);
		return PushFramework::Protocol::eDecodingFailure;
	}

	lpMessage = pQoSPacket;
	uExtractedBytes = packetLen;
	serviceId = 1;
	return PushFramework::Protocol::Success;
}

*/
QoSExampleProtocol::QoSExampleProtocol( void )
{
	//
}

QoSExampleProtocol::~QoSExampleProtocol( void )
{
	//
}




CQoSPacket::CQoSPacket()
{
	pData = NULL;
	nSize = 0;
}

CQoSPacket::~CQoSPacket()
{
	if(pData){
		delete [] pData;								
		pData = NULL;
	}
	
}

bool CQoSPacket::Decode( char* pBuf, unsigned int nSize )
{
	this->nSize = nSize;
	pData = new char[nSize];
	CopyMemory(pData, pBuf, nSize);

	channelSourceId = 0;
	packetId = 0;

	*((BYTE*)(&channelSourceId))=pData[0];
	*((BYTE*)(&channelSourceId)+1)=pData[1];

	*((BYTE*)(&packetId))=pData[2];
	*((BYTE*)(&packetId)+1)=pData[3];

	return true;
}

bool CQoSPacket::Encode()
{
	if(pData)
		return true;

	pData = new char[8000];
	nSize = 8000;

	pData[0] = *(	(BYTE*)(&channelSourceId)		);
	pData[1] = *(	(BYTE*)(&channelSourceId) + 1	);

	pData[2] = *(	(BYTE*)(&packetId)		);
	pData[3] = *(	(BYTE*)(&packetId) + 1	);


	return true;
}
