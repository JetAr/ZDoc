
#include "Symbols.h"


class QOSEXAMPLEPROTOCOL_API CQoSPacket : public PushFramework::IncomingPacket, public PushFramework::OutgoingPacket
{
public:

	typedef enum
	{
		Packet
	};
	CQoSPacket();
	virtual ~CQoSPacket();

public:
	virtual bool Decode(char* pBuf, unsigned int nSize);
	virtual bool Encode();


public:
	int getDataSize(){return nSize;}
	char* getData(){return pData;}

public:
	unsigned int getChannelSourceId() const { return channelSourceId; }
	void setChannelSourceId(unsigned int val) { channelSourceId = val; }
	unsigned int getPacketId() const { return packetId; }
	void setPacketId(unsigned int val) { packetId = val; }


private:

	unsigned int channelSourceId;
	unsigned int packetId;
	int nSize;
	char* pData;
};


class QOSEXAMPLEPROTOCOL_API QoSExampleProtocol :
	public PushFramework::Protocol
{
public:
	QoSExampleProtocol(void);
	~QoSExampleProtocol(void);

/*
	virtual int serializeOutgoingPacket(PushFramework::OutgoingPacket* pPacket, char* pBuffer, unsigned int uBufferSize, unsigned int& uWrittenBytes);
	virtual int tryDeframeIncomingPacket(char* pBuffer, unsigned int uBufferSize, unsigned int& uCommandID, PushFramework::IncomingPacket*& lpMessage, unsigned int& uExtractedBytes);
*/
	virtual void disposeOutgoingPacket(PushFramework::OutgoingPacket* pPacket);
	virtual void disposeIncomingPacket(PushFramework::IncomingPacket* pPacket);

	//////////////////////////////////////////////////////////////////////////
	virtual int encodeOutgoingPacket(PushFramework::OutgoingPacket& packet);
	virtual int frameOutgoingPacket(PushFramework::OutgoingPacket& packet, PushFramework::DataBuffer& buffer, unsigned int& nWrittenBytes);

	virtual int tryDeframeIncomingPacket(PushFramework::DataBuffer& buffer, PushFramework::IncomingPacket*& pPacket, int& serviceId, unsigned int& nExtractedBytes);
	virtual int decodeIncomingPacket(PushFramework::IncomingPacket* pPacket, int& serviceId);
};



