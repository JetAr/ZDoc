#include "StdAfx.h"
#include "QoSClient.h"


CQoSClient::~CQoSClient(void)
{
}
