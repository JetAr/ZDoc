#pragma once

class CQoSClient : public PushFramework::Client
{
public:
	CQoSClient(std::string pseudo)
	{
		this->pseudo = pseudo;
	}
	~CQoSClient(void);
	virtual const char* getKey()
	{
		return pseudo.c_str();
	}
private:
	std::string pseudo;
};
