#include "StdAfx.h"
#include "QoSClientFactory.h"

#include "QoSClient.h"

CQoSClientFactory::CQoSClientFactory(void)
{
}

CQoSClientFactory::~CQoSClientFactory(void)
{
}

PushFramework::OutgoingPacket* CQoSClientFactory::onNewConnection( void*& lpContext )
{
	return NULL;
}

void CQoSClientFactory::onBeforeDisposeClient( PushFramework::Client* pClient )
{
	//
}

void CQoSClientFactory::onClientConnected( ClientKey key )
{
	CQoSClient* pClient = (CQoSClient*) getClient(key);
	if(!pClient)
		return;
	//
	cout << "New client connected" << std::endl;

	//
	returnClient(key);
}

void CQoSClientFactory::disposeClient( PushFramework::Client* pClient )
{
	delete pClient;
}

int CQoSClientFactory::onFirstRequest( PushFramework::IncomingPacket& request, void* lpContext, PushFramework::Client*& lpClient, PushFramework::OutgoingPacket*& lpPacket )
{
	cout << "on first request" << std::endl;


	static int clientId = 0;
	clientId++;

	char pPseudo[4];
	sprintf_s(pPseudo, 4, "%d", clientId);

	CQoSClient* pClient = new CQoSClient(pPseudo);
	lpClient = pClient;

	return PushFramework::ClientFactory::CreateClient;
}
