#include "StdAfx.h"
#include "QoSService.h"

#include "QoSClient.h"

CQoSService::CQoSService(void)
{
}

CQoSService::~CQoSService(void)
{
}

void CQoSService::handle( ClientKey clientKey, PushFramework::IncomingPacket* pRequest )
{
	CQoSClient* pClient = (CQoSClient*) getClient(clientKey);
	if(!pClient)
		return;




	returnClient(clientKey);
}
