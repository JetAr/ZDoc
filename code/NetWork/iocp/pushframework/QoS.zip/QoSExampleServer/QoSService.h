#pragma once

class CQoSService : public PushFramework::Service
{
public:
	CQoSService(void);
	~CQoSService(void);

	void handle( ClientKey clientKey, PushFramework::IncomingPacket* pRequest );

};
