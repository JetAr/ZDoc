﻿// mqv.cpp - written and placed in the public domain by Wei Dai

#include "pch.h"
#include "mqv.h"

NAMESPACE_BEGIN(CryptoPP)

#if !defined(NDEBUG) && !defined(CRYPTOPP_DOXYGEN_PROCESSING)
void TestInstantiations_MQV()
{
    MQV mqv;
}
#endif

NAMESPACE_END
