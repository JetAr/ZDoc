/*#include <boost/cstdint.hpp>
using boost::uint16_t;
using boost::int16_t;
using boost::uint32_t;
using boost::int32_t;
using boost::uint8_t;
using boost::int8_t;
using boost::off_t;*/
typedef unsigned short uint16_t;
typedef short int16_t;
typedef unsigned long uint32_t;
typedef long int32_t;
typedef unsigned char uint8_t;
typedef signed char int8_t;
typedef long off_t;